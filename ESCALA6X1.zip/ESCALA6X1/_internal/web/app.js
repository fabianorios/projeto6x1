"use strict";

/* Interface do ComandosDml. Sem dependências externas. */

/* === Tema claro/escuro === */
(function initTema() {
  const salvo = localStorage.getItem("comandosdml.tema");
  if (salvo === "claro") document.documentElement.setAttribute("data-tema", "claro");
})();

const el = (id) => document.getElementById(id);

/* etapa 1 */
const zonaDrop = el("zona-drop");
const entradaArquivo = el("entrada-arquivo");
const linhaProjeto = el("linha-projeto");
const btnUsarProjeto = el("btn-usar-projeto");
const estatisticas = el("estatisticas");
const blocoNativo = el("bloco-nativo");
const blocoSemDicionario = el("bloco-sem-dicionario");
const statusIndice = el("status-indice");
const statusIndiceAlt = el("status-indice-alt");
const detalhesOutraVersao = el("detalhes-outra-versao");
const resumoOutraVersao = el("resumo-outra-versao");

/* Onde escrever o status do dicionário depende do bloco que está visível. */
const statusEmBloco = new Set([statusIndice, statusIndiceAlt]);

function statusDicionario() {
  return blocoSemDicionario.hidden ? statusIndice : statusIndiceAlt;
}

/* etapa 2 */
const campoPedido = el("campo-pedido");
const campoLimite = el("campo-limite");
const btnAnalisar = el("btn-analisar");
const btnLimparPesquisa = el("btn-limpar-pesquisa");
const statusPedido = el("status-pedido");
const grupoModo = el("grupo-modo");
const dicaAprofundar = el("dica-aprofundar");
const dicaTexto = el("dica-texto");
const btnAprofundar = el("btn-aprofundar");

/* etapa 3 */
const etapaResultado = el("etapa-resultado");
const painelAnalise = el("painel-analise");
const listaTabelas = el("lista-tabelas");
const contadorSelecao = el("contador-selecao");
const btnMarcarTodas = el("btn-marcar-todas");
const btnDesmarcarTodas = el("btn-desmarcar-todas");

const btnGerar = el("btn-gerar");
const btnCopiarPrompt = el("btn-copiar-prompt");
const btnSalvarTxt = el("btn-salvar-txt");
const statusGeracao = el("status-geracao");

const caixaScript = el("caixa-script");
const saidaPrompt = el("saida-prompt");
const tamanhoPrompt = el("tamanho-prompt");
const avisoDesatualizado = el("aviso-desatualizado");

const blocoProvedor = el("bloco-provedor");
const caixaComando = el("caixa-comando");
const saidaComando = el("saida-comando");
const btnCopiarComando = el("btn-copiar-comando");

/* estado */
let pedidoAtual = "";
let limiteAtual = 20;
let modoAtual = "exata";
let scriptAtual = "";
let nomeArquivoScript = "script-ia.txt";
let temProvedorAutomatico = false;

/* ---------------------------------------------------------------- utils */

const numero = (v) => Number(v).toLocaleString("pt-BR");

function definirStatus(nodo, texto, classe = "") {
  nodo.textContent = texto;
  nodo.className = statusEmBloco.has(nodo) ? "status" : "status-inline";
  if (classe) nodo.classList.add(classe);
}

async function chamar(url, opcoes = {}) {
  const resp = await fetch(url, opcoes);
  let dados = null;
  try {
    dados = await resp.json();
  } catch {
    throw new Error(`Resposta inválida do servidor (HTTP ${resp.status})`);
  }
  if (!resp.ok) throw new Error(dados && dados.erro ? dados.erro : `HTTP ${resp.status}`);
  return dados;
}

async function copiar(texto, botao) {
  const rotuloOriginal = botao.textContent;
  try {
    await navigator.clipboard.writeText(texto);
    botao.textContent = "Copiado";
  } catch {
    botao.textContent = "Copie com Ctrl+C";
  }
  setTimeout(() => {
    botao.textContent = rotuloOriginal;
  }, 1800);
}

/* -------------------------------------------------------------- etapa 1 */

function habilitarPedido(habilitar) {
  campoPedido.disabled = !habilitar;
  campoLimite.disabled = !habilitar;
  btnAnalisar.disabled = !habilitar;
  btnLimparPesquisa.disabled = !habilitar;
  grupoModo.disabled = !habilitar;
}

function modoEscolhido() {
  const marcado = document.querySelector('input[name="modo"]:checked');
  return marcado ? marcado.value : "exata";
}

function definirModo(valor) {
  const alvo = document.querySelector(`input[name="modo"][value="${valor}"]`);
  if (alvo) alvo.checked = true;
}

function mostrarEstatisticas(est) {
  const itens = [
    ["Tabelas", est.tabelas],
    ["Campos", est.campos],
    ["Assuntos", est.assuntos],
    ["Relações", est.relacoes],
    ["Índices", est.indices],
    ["Tamanho", `${(Number(est.bytes) / 1048576).toFixed(1)} MB`],
  ];
  estatisticas.innerHTML = itens
    .map(([rotulo, valor]) => {
      const mostrado = typeof valor === "number" ? numero(valor) : valor;
      return `<div><dt>${rotulo}</dt><dd>${mostrado}</dd></div>`;
    })
    .join("");
  estatisticas.hidden = false;
}

function aplicarLayoutDicionario(estado) {
  const temNativo = Boolean(estado.dicionario_do_projeto_existe);

  blocoNativo.hidden = !temNativo;
  blocoSemDicionario.hidden = temNativo;

  // Sem dicionário embutido, o envio é o caminho principal: abre a seção e
  // troca o rótulo, que só faz sentido como "outra versão" quando há uma nativa.
  if (!temNativo) {
    detalhesOutraVersao.open = true;
    resumoOutraVersao.textContent = "Enviar o dicionário";
  } else {
    resumoOutraVersao.textContent = "Usar outra versão do dicionário";
  }

  // O atalho de voltar ao nativo só aparece quando há nativo e o índice atual
  // veio de outro arquivo.
  linhaProjeto.hidden = !(temNativo && estado.pronto && !estado.usando_dicionario_do_projeto);
}

function mostrarIndexado(estado) {
  const proprio = estado.usando_dicionario_do_projeto;
  definirStatus(
    statusDicionario(),
    proprio
      ? `Pronto: ${estado.nome_arquivo}`
      : `Pronto, usando a versão enviada: ${estado.nome_arquivo}`,
    "status-ok"
  );
  mostrarEstatisticas(estado.estatisticas);
  habilitarPedido(true);
}

async function aplicarEstado() {
  try {
    const estado = await chamar("/api/estado");
    temProvedorAutomatico = Boolean(estado.provedor_automatico);
    aplicarLayoutDicionario(estado);

    if (estado.pronto) {
      mostrarIndexado(estado);
      return;
    }

    // O dicionário vem com a aplicação, então a leitura acontece sozinha:
    // o usuário não deveria precisar clicar em nada no caso comum.
    if (estado.dicionario_do_projeto_existe) {
      await indexarDoProjeto();
    }
  } catch (e) {
    definirStatus(statusDicionario(), e.message, "status-erro");
  }
}

async function indexarUpload(arquivo) {
  const mb = (arquivo.size / 1048576).toFixed(1);
  const alvo = statusDicionario();
  definirStatus(alvo, `Lendo ${arquivo.name} (${mb} MB)...`, "status-trabalhando");
  habilitarPedido(false);
  estatisticas.hidden = true;

  try {
    const dados = await chamar("/api/indexar", {
      method: "POST",
      headers: {
        "Content-Type": "application/octet-stream",
        "X-Nome-Arquivo": encodeURIComponent(arquivo.name),
      },
      body: arquivo,
    });
    definirStatus(alvo, `Pronto, usando a versão enviada: ${arquivo.name}`, "status-ok");
    mostrarEstatisticas(dados.estatisticas);
    habilitarPedido(true);
    aplicarLayoutDicionario(dados.resumo);
    detalhesOutraVersao.open = false;
    campoPedido.focus();
  } catch (e) {
    definirStatus(alvo, e.message, "status-erro");
  }
}

/* Upload inteligente: separa o dicionário dos auxiliares e trata cada um.
   A lista espelha os nomes aceitos pelo backend (/api/upload-auxiliar). O
   ComandosViews.txt entra aqui — sem ele, o JOIN com views não funciona. */
const NOMES_AUXILIARES = [
  "tabelas.txt", "objetos.txt", "campos.txt",
  "modulos.txt", "rotinas.txt", "rotinasxobjetos.txt",
  "comandosviews.txt",
];
const statusImport = el("status-import");

async function processarArquivos(fileList) {
  const arquivos = Array.from(fileList);
  if (!arquivos.length) return;

  const dicionario = arquivos.find(
    (f) => f.name.toLowerCase().includes("dicion") && f.name.toLowerCase().endsWith(".txt")
  );
  const auxiliares = arquivos.filter((f) =>
    NOMES_AUXILIARES.includes(f.name.toLowerCase())
  );

  const mensagens = [];

  // 1) Se veio o dicionário, indexa.
  if (dicionario) {
    await indexarUpload(dicionario);
    mensagens.push(`Dicionário: ${dicionario.name} indexado`);
  }

  // 2) Auxiliares: envia cada um para /api/upload-auxiliar.
  for (const arq of auxiliares) {
    try {
      await chamar("/api/upload-auxiliar", {
        method: "POST",
        headers: {
          "Content-Type": "application/octet-stream",
          "X-Nome-Arquivo": encodeURIComponent(arq.name),
        },
        body: arq,
      });
      mensagens.push(`${arq.name}: salvo`);
    } catch (e) {
      mensagens.push(`${arq.name}: erro — ${e.message}`);
    }
  }

  // 3) Se importou auxiliares, recarrega.
  if (auxiliares.length) {
    try {
      const resp = await chamar("/api/recarregar-auxiliares", { method: "POST" });
      mensagens.push(`Dados auxiliares: ${resp.mensagem}`);
    } catch (e) {
      mensagens.push(`Recarregar auxiliares: ${e.message}`);
    }
  }

  if (mensagens.length && statusImport) {
    statusImport.textContent = mensagens.join(" · ");
    statusImport.className = "status status-ok";
  }

  // Se não era nem dicionário nem auxiliar reconhecido:
  if (!dicionario && !auxiliares.length) {
    const nomes = arquivos.map((f) => f.name).join(", ");
    if (statusImport) {
      statusImport.textContent = `Arquivo(s) não reconhecido(s): ${nomes}. Aceitos: Dicionário de Dados.TXT, tabelas.txt, objetos.txt, campos.txt`;
      statusImport.className = "status status-erro";
    }
  }
}

async function indexarDoProjeto() {
  const alvo = statusDicionario();
  definirStatus(alvo, "Lendo o dicionário da aplicação...", "status-trabalhando");
  habilitarPedido(false);
  btnUsarProjeto.disabled = true;
  estatisticas.hidden = true;
  try {
    const dados = await chamar("/api/indexar-projeto", { method: "POST" });
    definirStatus(alvo, `Pronto: ${dados.resumo.nome_arquivo}`, "status-ok");
    mostrarEstatisticas(dados.estatisticas);
    habilitarPedido(true);
    aplicarLayoutDicionario(dados.resumo);
    detalhesOutraVersao.open = false;
  } catch (e) {
    definirStatus(alvo, e.message, "status-erro");
  } finally {
    btnUsarProjeto.disabled = false;
  }
}

zonaDrop.addEventListener("click", () => entradaArquivo.click());
zonaDrop.addEventListener("keydown", (ev) => {
  if (ev.key === "Enter" || ev.key === " ") {
    ev.preventDefault();
    entradaArquivo.click();
  }
});

["dragenter", "dragover"].forEach((evento) =>
  zonaDrop.addEventListener(evento, (ev) => {
    ev.preventDefault();
    zonaDrop.classList.add("arrastando");
  })
);

["dragleave", "drop"].forEach((evento) =>
  zonaDrop.addEventListener(evento, (ev) => {
    ev.preventDefault();
    zonaDrop.classList.remove("arrastando");
  })
);

zonaDrop.addEventListener("drop", (ev) => {
  const arquivos = ev.dataTransfer.files;
  if (arquivos.length) processarArquivos(arquivos);
});

entradaArquivo.addEventListener("change", () => {
  const arquivos = entradaArquivo.files;
  if (arquivos.length) processarArquivos(arquivos);
});

btnUsarProjeto.addEventListener("click", indexarDoProjeto);

/* -------------------------------------------------------------- etapa 2 */

campoPedido.addEventListener("keydown", (ev) => {
  if (ev.key === "Enter" && (ev.ctrlKey || ev.metaKey)) {
    ev.preventDefault();
    analisar();
  }
});

/* O campo de pedido cresce sozinho conforme o texto: zera a altura para o
   scrollHeight refletir só o conteúdo, e depois adota esse valor. O min-height
   do CSS garante a altura inicial; aqui só deixamos passar dela quando precisa. */
function ajustarAltura() {
  campoPedido.style.height = "auto";
  campoPedido.style.height = campoPedido.scrollHeight + "px";
}
campoPedido.addEventListener("input", ajustarAltura);

/* Auto-resize genérico para qualquer textarea: cresce conforme o conteúdo
   (inclusive ao colar), evitando a rolagem interna. Com teto opcional em px
   para não ocupar a tela inteira em textos muito longos. */
function autoCrescer(ta, tetoPx = 900) {
  if (!ta) return;
  const aplicar = () => {
    ta.style.height = "auto";
    const alvo = Math.min(ta.scrollHeight, tetoPx);
    ta.style.height = alvo + "px";
    // acima do teto, volta a rolar internamente
    ta.style.overflowY = ta.scrollHeight > tetoPx ? "auto" : "hidden";
  };
  ta.addEventListener("input", aplicar);
  // 'paste' dispara 'input', mas garantimos o ajuste no próximo tick também.
  ta.addEventListener("paste", () => setTimeout(aplicar, 0));
  aplicar();
}

/* --- Sugestões de tabelas enquanto digita --- */
const sugestoesTabela = el("sugestoes-tabela");
let timerSugestao = null;

/* Último termo digitado, separado por espaço OU vírgula. Assim "Folhas," ou
   "FOL_CdiFolha, CON_" ainda disparam sugestão para o trecho após a vírgula. */
function ultimoTermo(texto) {
  const partes = texto.split(/[\s,]+/);
  return partes[partes.length - 1] || "";
}

campoPedido.addEventListener("input", () => {
  const ultima = ultimoTermo(campoPedido.value);
  if (ultima.length < 2) {
    sugestoesTabela.hidden = true;
    return;
  }
  clearTimeout(timerSugestao);
  timerSugestao = setTimeout(() => buscarSugestoesTabela(ultima), 300);
});

campoPedido.addEventListener("blur", () => {
  setTimeout(() => { sugestoesTabela.hidden = true; }, 200);
});

async function buscarSugestoesTabela(termo) {
  try {
    const d = await chamar(`/api/sugerir-tabelas?q=${encodeURIComponent(termo)}`);
    if (!d.sugestoes.length) { sugestoesTabela.hidden = true; return; }
    sugestoesTabela.innerHTML = d.sugestoes.map(s => {
      // Quando a sugestão veio de um campo citado, o topo mostra "campo -> tabela"
      // para deixar claro a qual tabela aquele campo pertence.
      const titulo = s.campo
        ? `${s.campo} <span class="sugestao-seta">&rarr; tabela ${s.nome}</span>`
        : s.nome;
      // Cita o objeto (tela do Apdata) dono da tabela, quando conhecido.
      const objeto = s.objeto
        ? ` · objeto ${s.objeto.id}${s.objeto.descricao ? " — " + s.objeto.descricao : ""}`
        : "";
      return `<div class="sugestao-item" data-nome="${s.nome}" data-campo="${s.campo || ""}">` +
        `<span class="sugestao-id">${titulo}</span>` +
        `<span class="sugestao-desc">${s.descricao || s.assunto} · ${s.campos} campos${objeto}</span></div>`;
    }).join("");
    sugestoesTabela.hidden = false;

    sugestoesTabela.querySelectorAll(".sugestao-item").forEach(item => {
      item.addEventListener("mousedown", (ev) => {
        ev.preventDefault();
        // Se a sugestão veio de um campo (ex.: FOL_CdiFolha -> Folhas), mantém o
        // NOME DO CAMPO no texto: citar o campo exato é o que dá resultado exato.
        // Para sugestões de tabela, insere o nome da tabela.
        const inserir = item.dataset.campo || item.dataset.nome;
        // Substitui só o último termo (após o último espaço ou vírgula),
        // preservando o que veio antes. Ex.: "Folhas, CON" -> "Folhas, Contratados ".
        const texto = campoPedido.value.trimEnd();
        const corte = Math.max(texto.lastIndexOf(" "), texto.lastIndexOf(","));
        const prefixo = corte >= 0 ? texto.slice(0, corte + 1) : "";
        const separador = prefixo && !prefixo.endsWith(" ") ? " " : "";
        campoPedido.value = prefixo + separador + inserir + " ";
        sugestoesTabela.hidden = true;
        ajustarAltura();
        campoPedido.focus();
      });
    });
  } catch {
    sugestoesTabela.hidden = true;
  }
}

function renderAnalise(a) {
  const etiquetas = [];
  if (a.operacao) {
    etiquetas.push(`<span class="etiqueta etiqueta-op">${a.operacao}</span>`);
  } else {
    etiquetas.push(`<span class="etiqueta">operação não detectada</span>`);
  }
  if (a.destrutivo) {
    etiquetas.push(`<span class="etiqueta etiqueta-perigo">altera dados</span>`);
  }
  if (a.termos.length) {
    etiquetas.push(`<span class="etiqueta">termos: ${a.termos.join(", ")}</span>`);
  }
  if (a.campos_citados.length) {
    etiquetas.push(
      `<span class="etiqueta">campos citados: ${a.campos_citados.join(", ")}</span>`
    );
  }
  if (a.numeros.length) {
    etiquetas.push(`<span class="etiqueta">números: ${a.numeros.join(", ")}</span>`);
  }
  painelAnalise.innerHTML = etiquetas.join("");
}

function renderTabelas(tabelas) {
  if (!tabelas.length) {
    listaTabelas.innerHTML =
      "<li>Nenhuma tabela casou com o pedido. Tente citar o nome da tabela ou um campo.</li>";
    contadorSelecao.textContent = "";
    return;
  }

  listaTabelas.innerHTML = tabelas
    .map((t, i) => {
      const motivos = t.motivos.map((m) => `<li>${m}</li>`).join("");
      const vizinha = t.vizinha_de ? " tabela-vizinha" : "";
      const idMarca = `marca-${i}`;
      const posicao = t.posicao || i + 1;
      const codigoTag = t.codigo != null
        ? `<span class="tabela-codigo" title="ATB_CdiTabela">#${t.codigo}</span>`
        : "";
      const objetosHtml = t.objetos && t.objetos.length
        ? `<div class="tabela-objetos">Objeto(s): ${t.objetos.map(o =>
            `<span class="tag-objeto" title="OBJ_CdiObjeto = ${o.id}">${o.id} — ${o.descricao || "sem descrição"}</span>`
          ).join(" ")}</div>`
        : "";

      return `<li class="${vizinha}">
        <input type="checkbox" class="marca-tabela" id="${idMarca}"
               data-nome="${t.nome}" checked
               aria-label="Incluir a tabela ${t.nome} no script">
        <div class="corpo-tabela">
          <div class="tabela-cabecalho">
            <span class="tabela-posicao" aria-hidden="true">${posicao}</span>
            <label class="tabela-nome" for="${idMarca}">${t.nome}</label>
            ${codigoTag}
            <span class="tabela-pontos">${t.pontos} pts</span>
          </div>
          <div class="tabela-meta">
            ${t.classificacao} · ${numero(t.qtd_campos)} campos ·
            ${numero(t.qtd_indices)} índices · ${numero(t.qtd_relacoes)} FKs ·
            linha ${numero(t.linha)} do dicionário · assunto: ${t.assunto}
          </div>
          <div class="tabela-prefixo-linha">Prefixo dos campos: <span class="tabela-prefixo">${t.prefixo}_</span></div>
          ${t.codigo != null ? `<div class="tabela-numero-linha">Número da tabela: <strong>${t.codigo}</strong></div>` : ""}
          ${t.descricao_tabela ? `<div class="tabela-descricao">${t.descricao_tabela}</div>` : ""}
          ${objetosHtml}
          <ul class="tabela-motivos">${motivos}</ul>
        </div>
      </li>`;
    })
    .join("");

  listaTabelas.querySelectorAll(".marca-tabela").forEach((cx) => {
    cx.addEventListener("change", aoMudarSelecao);
  });
  atualizarSelecao();
}

function marcas() {
  return Array.from(listaTabelas.querySelectorAll(".marca-tabela"));
}

function selecionadas() {
  return marcas()
    .filter((c) => c.checked)
    .map((c) => c.dataset.nome);
}

function atualizarSelecao() {
  const todas = marcas();
  const escolhidas = selecionadas();

  todas.forEach((c) => {
    c.closest("li").classList.toggle("desmarcada", !c.checked);
  });

  contadorSelecao.textContent = todas.length
    ? `${escolhidas.length} de ${todas.length} selecionadas`
    : "";
  btnGerar.disabled = escolhidas.length === 0;
}

function limparEtiquetasOrcamento() {
  listaTabelas.querySelectorAll(".etiqueta-orcamento").forEach((e) => e.remove());
  listaTabelas.querySelectorAll("li").forEach((li) => {
    li.classList.remove("sem-espaco", "resumida");
  });
}

/* Marcar quem ficou de fora por orçamento é essencial: com muitas tabelas
   marcadas, a maioria pode não entrar no recorte, e sem aviso o usuário
   acreditaria que enviou tudo. */
function marcarNaoCouberam(omitidas, resumidas) {
  limparEtiquetasOrcamento();

  const rotular = (nomes, classe, texto, titulo) => {
    nomes.forEach((nome) => {
      const cx = listaTabelas.querySelector(`.marca-tabela[data-nome="${nome}"]`);
      if (!cx) return;
      const li = cx.closest("li");
      li.classList.add(classe);
      const etiqueta = document.createElement("span");
      etiqueta.className = `etiqueta etiqueta-orcamento ${classe}-etiqueta`;
      etiqueta.textContent = texto;
      etiqueta.title = titulo;
      li.querySelector(".tabela-cabecalho").appendChild(etiqueta);
    });
  };

  rotular(
    resumidas || [],
    "resumida",
    "resumida",
    "Entrou como lista compacta de campos, sem os índices, por falta de espaço."
  );
  rotular(
    omitidas || [],
    "sem-espaco",
    "não entrou: sem espaço",
    "Marcada, mas não couber no orçamento do script. Desmarque outras tabelas para abrir espaço."
  );
}

function aoMudarSelecao() {
  atualizarSelecao();
  limparEtiquetasOrcamento();
  // O script já gerado não corresponde mais à seleção: avisa em vez de deixar
  // o usuário copiar algo defasado sem perceber.
  if (scriptAtual) {
    avisoDesatualizado.hidden = false;
    btnCopiarPrompt.disabled = true;
    btnSalvarTxt.disabled = true;
    definirStatus(statusGeracao, "Seleção mudou. Gere o script novamente.", "status-trabalhando");
  }
  if (selecionadas().length === 0) {
    definirStatus(statusGeracao, "Marque ao menos uma tabela.", "status-erro");
  }
}

btnMarcarTodas.addEventListener("click", () => {
  marcas().forEach((c) => {
    c.checked = true;
  });
  aoMudarSelecao();
});

btnDesmarcarTodas.addEventListener("click", () => {
  marcas().forEach((c) => {
    c.checked = false;
  });
  aoMudarSelecao();
});

async function analisar() {
  const pedido = campoPedido.value.trim();
  if (!pedido) {
    definirStatus(statusPedido, "Escreva o pedido primeiro.", "status-erro");
    campoPedido.focus();
    return;
  }

  btnAnalisar.disabled = true;
  definirStatus(statusPedido, "Pesquisando no dicionário...", "status-trabalhando");
  definirStatus(statusGeracao, "");
  caixaScript.hidden = true;
  caixaComando.hidden = true;
  blocoProvedor.hidden = true;
  avisoDesatualizado.hidden = true;
  dicaAprofundar.hidden = true;
  scriptAtual = "";
  btnCopiarPrompt.disabled = true;
  btnSalvarTxt.disabled = true;

  const modo = modoEscolhido();

  try {
    const dados = await chamar("/api/pedido", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ pedido, limite: Number(campoLimite.value) || 20, modo }),
    });

    pedidoAtual = pedido;
    limiteAtual = Number(campoLimite.value) || 20;
    modoAtual = dados.busca ? dados.busca.modo : modo;

    renderAnalise(dados.analise);
    renderTabelas(dados.tabelas);
    mostrarDica(dados);

    etapaResultado.hidden = false;
    const rotuloModo = modoAtual === "exata" ? "exatas" : "relacionadas";
    definirStatus(
      statusPedido,
      `${dados.tabelas.length} tabela(s) ${rotuloModo}`,
      dados.tabelas.length ? "status-ok" : "status-trabalhando"
    );
    etapaResultado.scrollIntoView({ behavior: "smooth", block: "start" });
  } catch (e) {
    definirStatus(statusPedido, e.message, "status-erro");
  } finally {
    btnAnalisar.disabled = false;
  }
}

/* O modo exato pode não achar nada, ou deixar relacionadas de fora. Em vez de o
   usuário adivinhar, a tela diz quantas existem e oferece o aprofundamento. */
function mostrarDica(dados) {
  const b = dados.busca;
  if (!b || modoAtual !== "exata") {
    dicaAprofundar.hidden = true;
    return;
  }

  const n = b.relacionadas_disponiveis;

  if (!dados.tabelas.length) {
    dicaTexto.textContent = n
      ? "Nenhuma tabela com o nome digitado. A pesquisa aprofundada encontra tabelas relacionadas ao termo."
      : "Nenhuma tabela encontrada. Tente outro termo, o nome exato da tabela, ou cite um campo (PST_CdiContratado).";
    dicaAprofundar.hidden = !n;
    return;
  }

  if (n > 0) {
    dicaTexto.textContent =
      `A pesquisa aprofundada traria até ${n} tabela(s) relacionada(s) além desta(s).`;
    dicaAprofundar.hidden = false;
    return;
  }

  dicaAprofundar.hidden = true;
}

btnAnalisar.addEventListener("click", analisar);

btnLimparPesquisa.addEventListener("click", () => {
  campoPedido.value = "";
  ajustarAltura();
  etapaResultado.hidden = true;
  listaTabelas.innerHTML = "";
  painelAnalise.innerHTML = "";
  contadorSelecao.textContent = "";
  caixaScript.hidden = true;
  caixaComando.hidden = true;
  blocoProvedor.hidden = true;
  scriptAtual = "";
  pedidoAtual = "";
  btnCopiarPrompt.disabled = true;
  btnSalvarTxt.disabled = true;
  dicaAprofundar.hidden = true;
  definirStatus(statusPedido, "");
  definirStatus(statusGeracao, "");
  campoPedido.focus();
});

btnAprofundar.addEventListener("click", () => {
  definirModo("relacionada");
  dicaAprofundar.hidden = true;
  analisar();
});

// Trocar o modo com um resultado na tela deixa a lista defasada: refaz na hora.
document.querySelectorAll('input[name="modo"]').forEach((r) => {
  r.addEventListener("change", () => {
    if (!etapaResultado.hidden && pedidoAtual) analisar();
  });
});

/* -------------------------------------------------------------- etapa 3 */

function bancoEscolhido() {
  const marcado = document.querySelector('input[name="banco"]:checked');
  return marcado ? marcado.value : "";
}

btnGerar.addEventListener("click", async () => {
  const escolhidas = selecionadas();
  if (!escolhidas.length) {
    definirStatus(statusGeracao, "Marque ao menos uma tabela.", "status-erro");
    return;
  }

  const banco = bancoEscolhido();
  if (!banco) {
    definirStatus(
      statusGeracao,
      "Informe o banco de destino (Oracle ou SQL Server) antes de gerar o script.",
      "status-erro"
    );
    return;
  }

  btnGerar.disabled = true;
  definirStatus(statusGeracao, "Montando o script...", "status-trabalhando");

  try {
    const d = await chamar("/api/script", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        pedido: pedidoAtual,
        tabelas: escolhidas,
        limite: limiteAtual,
        modo: modoAtual,
        banco,
      }),
    });

    scriptAtual = d.texto;
    nomeArquivoScript = d.nome_arquivo || "script-ia.txt";
    saidaPrompt.textContent = scriptAtual;

    const partes = [`${numero(d.chars)} caracteres`, `~${numero(d.tokens_estimados)} tokens`];
    if (d.resumidas.length) partes.push(`${d.resumidas.length} resumida(s)`);
    if (d.omitidas.length) partes.push(`${d.omitidas.length} não couberam`);
    tamanhoPrompt.textContent = `(${partes.join(", ")})`;

    caixaScript.hidden = false;
    avisoDesatualizado.hidden = true;
    btnCopiarPrompt.disabled = false;
    btnSalvarTxt.disabled = false;
    caixaComando.hidden = true;

    marcarNaoCouberam(d.omitidas, d.resumidas);

    const partesStatus = [`Script com ${d.usadas.length} tabela(s)`];
    if (d.descartadas.length) partesStatus.push(`${d.descartadas.length} desmarcada(s)`);
    if (d.omitidas.length) {
      partesStatus.push(`${d.omitidas.length} sem espaço no orçamento`);
    }
    definirStatus(
      statusGeracao,
      partesStatus.join(", ") + ". Copie e cole na IA de sua preferência.",
      d.omitidas.length ? "status-trabalhando" : "status-ok"
    );
    caixaScript.scrollIntoView({ behavior: "smooth", block: "start" });
    btnCopiarPrompt.focus();
  } catch (e) {
    definirStatus(statusGeracao, e.message, "status-erro");
  } finally {
    btnGerar.disabled = selecionadas().length === 0;
  }
});

btnCopiarPrompt.addEventListener("click", () => copiar(scriptAtual, btnCopiarPrompt));

btnSalvarTxt.addEventListener("click", () => {
  if (!scriptAtual) return;
  exportarArquivo(
    "texto",
    { texto: scriptAtual, nome: nomeArquivoScript },
    statusGeracao
  );
});

btnCopiarComando.addEventListener("click", () =>
  copiar(saidaComando.textContent, btnCopiarComando)
);

/* --- exportar xlsx --- */

/* Carimbo de data/hora para nomes de arquivo: DD-MM-AAAA-HH-MM. */
function carimboArquivo() {
  const a = new Date();
  const p = (n) => n.toString().padStart(2, "0");
  return `${p(a.getDate())}-${p(a.getMonth() + 1)}-${a.getFullYear()}-${p(a.getHours())}-${p(a.getMinutes())}`;
}

/* Exporta um arquivo via download.

   A ferramenta abre numa janela do Edge (modo aplicativo) ou num navegador; nos
   dois casos o download é do navegador, que cuida de onde salvar conforme a
   configuração do usuário (a opção "Perguntar onde salvar cada arquivo antes de
   baixar" no Edge faz aparecer o "Salvar como").

   tipo: "xlsx" ou "texto".
   opcoes: { nome, tabelas?, so_cadeia?, texto? }
   statusNode: onde mostrar a mensagem. */
function exportarArquivo(tipo, opcoes, statusNode) {
  const nome = opcoes.nome;
  if (tipo === "xlsx") {
    let params = "";
    if (opcoes.tabelas && opcoes.tabelas.length) {
      params = `?tabelas=${encodeURIComponent(opcoes.tabelas.join(","))}`;
    } else if (opcoes.so_cadeia) {
      params = "?so_cadeia=1";
    }
    baixarLink(`/api/exportar-xlsx${params}`, nome);
  } else {
    const blob = new Blob(["\ufeff" + (opcoes.texto || "")], {
      type: "text/plain;charset=utf-8",
    });
    const url = URL.createObjectURL(blob);
    baixarLink(url, nome);
    URL.revokeObjectURL(url);
  }
  definirStatus(statusNode, `Baixando ${nome}...`, "status-ok");
  return true;
}

/* Dispara um download no navegador via <a download>. */
function baixarLink(href, nome) {
  const a = document.createElement("a");
  a.href = href;
  a.download = nome;
  document.body.appendChild(a);
  a.click();
  a.remove();
}

const btnExportarXlsx = el("btn-exportar-xlsx");

btnExportarXlsx.addEventListener("click", () => {
  const escolhidas = selecionadas();
  if (!escolhidas.length) {
    definirStatus(statusGeracao, "Marque ao menos uma tabela.", "status-erro");
    return;
  }
  exportarArquivo(
    "xlsx",
    { tabelas: escolhidas, nome: `Tabelas-${carimboArquivo()}.xlsx` },
    statusGeracao
  );
});

/* ------------------------------------------------------------- saudacao */

const saudacaoTitulo = el("saudacao-titulo");
const saudacaoFrase = el("saudacao-frase");

function saudar() {
  const h = new Date().getHours();
  let periodo;
  if (h < 12) periodo = "Bom dia";
  else if (h < 18) periodo = "Boa tarde";
  else periodo = "Boa noite";

  // Várias mensagens otimistas por período. A ferramenta escolhe uma
  // automaticamente a cada abertura, para a saudação não ficar repetitiva.
  const frases = {
    "Bom dia": [
      "Bora começar com tudo! A cada comando que você monta aqui, aprende um pouco mais da estrutura do Apdata — tabelas, campos, relações e as telas por trás de cada dado.",
      "Dia novo, oportunidade nova de evoluir! Descreva o que precisa em português e deixe a ferramenta achar o caminho — o conhecimento do dicionário vem junto.",
      "Vamos nessa! Cada busca te deixa mais afiado na estrutura do Apdata. Comece descrevendo o que precisa e vá explorando com segurança.",
      "Comece o dia no controle: monte comandos com segurança e entenda melhor como as tabelas do Apdata se conectam. Você no comando, a ferramenta no apoio.",
    ],
    "Boa tarde": [
      "Mãos à obra! Use a ferramenta para montar seus comandos com segurança e, de quebra, entender melhor como o Apdata se organiza.",
      "Boa hora para avançar! Quanto mais você explora o dicionário, mais autônomo e confiante fica no dia a dia.",
      "Siga firme! Cada comando validado aqui é um aprendizado a mais sobre tabelas, campos e relações do Apdata.",
      "Produtividade com conhecimento: descreva o que precisa, confira o recorte e aprenda a lógica por trás dos dados.",
    ],
    "Boa noite": [
      "Fim de expediente, mas sempre dá tempo de evoluir! Monte seu comando com calma e fixe o que aprendeu sobre o Apdata.",
      "Reta final do dia! Aproveite para revisar seus comandos com atenção — cada consulta é um passo a mais no seu domínio da ferramenta.",
      "Trabalho tranquilo agora: descreva, confira o recorte e gere com segurança. O conhecimento acumulado fica com você.",
      "Boa hora para caprichar: valide seus comandos e termine o dia sabendo um pouco mais da estrutura do Apdata.",
    ],
  };

  const opcoes = frases[periodo];
  const escolhida = opcoes[Math.floor(Math.random() * opcoes.length)];
  saudacaoTitulo.textContent = `${periodo}, Apstar! ✨`;
  saudacaoFrase.textContent = escolhida;
}

/* ----------------------------------------------------- indicador online */

const indicador = el("indicador");
const indicadorTexto = el("indicador-texto");
const indicadorTempo = el("indicador-tempo");
const indicadorEstacao = el("indicador-estacao");
const painelOffline = el("painel-offline");
const caminhoIniciar = el("caminho-iniciar");
const btnCopiarCaminho = el("btn-copiar-caminho");

const CHAVE_RAIZ = "comandosdml.raiz";
const INTERVALO_ONLINE = 8000;
const INTERVALO_OFFLINE = 3000;

let timerVerificacao = null;
let estavaOffline = false;

function tempoNoAr(segundos) {
  if (segundos < 60) return "há poucos segundos";
  const min = Math.floor(segundos / 60);
  if (min < 60) return `há ${min} min`;
  const horas = Math.floor(min / 60);
  const resto = min % 60;
  if (horas < 24) return resto ? `há ${horas}h ${resto}min` : `há ${horas}h`;
  const dias = Math.floor(horas / 24);
  return `há ${dias} dia${dias > 1 ? "s" : ""}`;
}

/* A raiz vem do servidor e fica guardada porque, quando ele cai, não há a quem
   perguntar o caminho do iniciar.cmd — que é justamente o que o usuário precisa
   nesse momento. */
function guardarRaiz(raiz) {
  if (!raiz) return;
  try {
    localStorage.setItem(CHAVE_RAIZ, raiz);
  } catch {
    /* navegador sem localStorage: o painel cai no texto genérico */
  }
}

function caminhoDoIniciar() {
  let raiz = "";
  try {
    raiz = localStorage.getItem(CHAVE_RAIZ) || "";
  } catch {
    raiz = "";
  }
  if (!raiz) return "";
  return raiz.endsWith("\\") ? `${raiz}iniciar.cmd` : `${raiz}\\iniciar.cmd`;
}

function mostrarPainelOffline() {
  const caminho = caminhoDoIniciar();
  if (caminho) {
    caminhoIniciar.textContent = caminho;
    btnCopiarCaminho.hidden = false;
  } else {
    caminhoIniciar.textContent =
      "iniciar.cmd — na pasta onde a ferramenta foi instalada";
    btnCopiarCaminho.hidden = true;
  }
  painelOffline.hidden = false;
}

function reagendar(intervalo) {
  if (timerVerificacao) clearTimeout(timerVerificacao);
  timerVerificacao = setTimeout(verificarServidor, intervalo);
}

async function verificarServidor() {
  try {
    const estado = await chamar("/api/estado");

    indicador.className = "indicador online";
    indicadorTexto.textContent = "Servidor local online";
    indicadorTempo.textContent = `no ar ${tempoNoAr(estado.segundos_no_ar)}`;
    indicador.title = `Ativo na porta ${location.port || 80}, processo ${estado.pid}.`;

    /* Estação e hora de Brasília */
    const horaBrasilia = new Date().toLocaleString("pt-BR", {
      timeZone: "America/Sao_Paulo",
      hour: "2-digit", minute: "2-digit", second: "2-digit"
    });
    const estacaoInfo = estado.hostname
      ? `${estado.hostname} (${estado.ip}) · ${horaBrasilia}`
      : horaBrasilia;
    indicadorEstacao.textContent = estacaoInfo;

    guardarRaiz(estado.raiz);
    painelOffline.hidden = true;

    // Voltou depois de cair: recarrega o estado do dicionário, que pode ter
    // sido reindexado por outra instância.
    if (estavaOffline) {
      estavaOffline = false;
      aplicarEstado();
    }

    reagendar(INTERVALO_ONLINE);
    return true;
  } catch {
    indicador.className = "indicador offline";
    indicadorTexto.textContent = "Servidor local offline";
    indicadorTempo.textContent = "verificando de novo...";
    indicador.title = "O servidor local não está respondendo.";
    estavaOffline = true;
    mostrarPainelOffline();

    // Enquanto está fora, pergunta mais vezes, para a tela voltar sozinha
    // logo depois de o usuário rodar o iniciar.cmd.
    reagendar(INTERVALO_OFFLINE);
    return false;
  }
}

btnCopiarCaminho.addEventListener("click", () =>
  copiar(caminhoDoIniciar(), btnCopiarCaminho)
);

/* ------------------------------------------------------- pesquisa por objeto */

const campoObjeto = el("campo-objeto");
const sugestoesObjeto = el("sugestoes-objeto");
const btnPesquisarObjeto = el("btn-pesquisar-objeto");
const btnLimparObjeto = el("btn-limpar-objeto");
const statusObjeto = el("status-objeto");
const resultadoObjeto = el("resultado-objeto");
const tituloObjetoResultado = el("titulo-objeto-resultado");
const listaTabelasObjeto = el("lista-tabelas-objeto");
const btnExportarTodos = el("btn-exportar-todos");

let objetoAtualId = null;
let timerBusca = null;

/* --- sugestões dinâmicas --- */

campoObjeto.addEventListener("input", () => {
  const texto = campoObjeto.value.trim();
  if (texto.length < 2) {
    sugestoesObjeto.hidden = true;
    return;
  }
  clearTimeout(timerBusca);
  timerBusca = setTimeout(() => buscarSugestoes(texto), 250);
});

campoObjeto.addEventListener("blur", () => {
  // Delay para permitir o clique na sugestão registrar.
  setTimeout(() => {
    sugestoesObjeto.hidden = true;
  }, 200);
});

async function buscarSugestoes(texto) {
  try {
    const d = await chamar(`/api/objetos?q=${encodeURIComponent(texto)}`);
    if (!d.objetos.length) {
      sugestoesObjeto.hidden = true;
      return;
    }
    sugestoesObjeto.innerHTML = d.objetos
      .slice(0, 30)
      .map(
        (o) =>
          `<div class="sugestao-item" data-id="${o.id}">` +
          `<span class="sugestao-id">${o.id}</span>` +
          `<span class="sugestao-desc">${o.descricao}${o.via_tabela ? ` <em>(tabela: ${o.via_tabela})</em>` : ""}</span></div>`
      )
      .join("");
    sugestoesObjeto.hidden = false;

    sugestoesObjeto.querySelectorAll(".sugestao-item").forEach((item) => {
      item.addEventListener("mousedown", (ev) => {
        ev.preventDefault();
        const id = parseInt(item.dataset.id, 10);
        const desc = item.querySelector(".sugestao-desc").textContent;
        campoObjeto.value = `${id} — ${desc}`;
        sugestoesObjeto.hidden = true;
        pesquisarObjetoPorId(id);
      });
    });
  } catch {
    sugestoesObjeto.hidden = true;
  }
}

/* --- pesquisa --- */

btnPesquisarObjeto.addEventListener("click", iniciarPesquisaObjeto);

campoObjeto.addEventListener("keydown", (ev) => {
  if (ev.key === "Enter") {
    ev.preventDefault();
    sugestoesObjeto.hidden = true;
    iniciarPesquisaObjeto();
  }
});

async function iniciarPesquisaObjeto() {
  const texto = campoObjeto.value.trim();
  if (!texto) {
    definirStatus(statusObjeto, "Informe o número ou nome do objeto.", "status-erro");
    return;
  }

  const match = texto.match(/^(\d+)/);
  if (match) {
    pesquisarObjetoPorId(parseInt(match[1], 10));
    return;
  }

  // Busca por texto (nome do objeto OU nome da tabela)
  try {
    const busca = await chamar(`/api/objetos?q=${encodeURIComponent(texto)}`);
    if (busca.objetos.length === 0) {
      definirStatus(statusObjeto, "Nenhum objeto encontrado com esse termo.", "status-erro");
      return;
    }
    if (busca.objetos.length === 1) {
      const o = busca.objetos[0];
      campoObjeto.value = `${o.id} — ${o.descricao}`;
      pesquisarObjetoPorId(o.id);
      return;
    }
    // Múltiplos: mostra as sugestões
    sugestoesObjeto.innerHTML = busca.objetos
      .slice(0, 30)
      .map(
        (o) =>
          `<div class="sugestao-item" data-id="${o.id}">` +
          `<span class="sugestao-id">${o.id}</span>` +
          `<span class="sugestao-desc">${o.descricao}${o.via_tabela ? ` (tabela: ${o.via_tabela})` : ""}</span></div>`
      )
      .join("");
    sugestoesObjeto.hidden = false;
    sugestoesObjeto.querySelectorAll(".sugestao-item").forEach((item) => {
      item.addEventListener("mousedown", (ev) => {
        ev.preventDefault();
        const id = parseInt(item.dataset.id, 10);
        const desc = item.querySelector(".sugestao-desc").textContent;
        campoObjeto.value = `${id} — ${desc}`;
        sugestoesObjeto.hidden = true;
        pesquisarObjetoPorId(id);
      });
    });
    definirStatus(
      statusObjeto,
      `${busca.objetos.length} resultado(s). Selecione da lista ou refine o termo.`,
      "status-trabalhando"
    );
  } catch (e) {
    definirStatus(statusObjeto, e.message, "status-erro");
  }
}

async function pesquisarObjetoPorId(id) {
  objetoAtualId = id;
  const modo = document.querySelector('input[name="modo-objeto"]:checked')?.value || "principal";
  const limite = el("campo-limite-objeto")?.value || "20";
  definirStatus(statusObjeto, "Pesquisando...", "status-trabalhando");

  try {
    const d = await chamar(`/api/tabelas-do-objeto?id=${id}&modo=${modo}&limite=${limite}`);
    const obj = d.objeto;
    tituloObjetoResultado.textContent =
      `Objeto ${obj.id} — ${obj.descricao || "sem descrição"} (${d.total_relacionadas} tabela(s) vinculadas)`;

    renderTabelasObjeto(d.tabelas, d.vinculo_exato);
    resultadoObjeto.hidden = false;
    definirStatus(statusObjeto, `${d.tabelas.length} tabela(s) exibida(s)`, "status-ok");
    resultadoObjeto.scrollIntoView({ behavior: "smooth", block: "start" });
  } catch (e) {
    definirStatus(statusObjeto, e.message, "status-erro");
  }
}

function renderTabelasObjeto(tabelas, vinculoExato) {
  if (!tabelas.length) {
    listaTabelasObjeto.innerHTML = "<li>Nenhuma tabela vinculada a este objeto.</li>";
    return;
  }

  listaTabelasObjeto.innerHTML = tabelas
    .map((t) => {
      const objProprioHtml = t.objeto_proprio
        ? `<div class="tabela-objetos">Objeto: <span class="tag-objeto">${t.objeto_proprio.id} — ${t.objeto_proprio.descricao || "sem descrição"}</span></div>`
        : "";

      return `<li>
      <div class="corpo-tabela">
        <div class="tabela-cabecalho">
          <span class="tabela-nome">${t.nome}</span>
          ${t.codigo != null ? `<span class="tabela-codigo">#${t.codigo}</span>` : ""}
        </div>
        <div class="tabela-meta">
          ${t.classificacao} · ${numero(t.qtd_campos)} campos ·
          ${numero(t.qtd_relacoes || 0)} FKs · assunto: ${t.assunto}
        </div>
        ${t.codigo != null ? `<div class="tabela-numero-linha">Número da tabela: ${t.codigo}</div>` : ""}
        <div class="tabela-prefixo-linha">Prefixo dos campos: <span class="tabela-prefixo">${t.prefixo}_</span></div>
        ${t.descricao_tabela ? `<div class="tabela-descricao">${t.descricao_tabela}</div>` : ""}
        ${objProprioHtml}
      </div>
    </li>`;
    })
    .join("");
}

/* Trocar modo refaz a pesquisa */
document.querySelectorAll('input[name="modo-objeto"]').forEach((r) => {
  r.addEventListener("change", () => {
    if (objetoAtualId != null) pesquisarObjetoPorId(objetoAtualId);
  });
});

btnLimparObjeto.addEventListener("click", () => {
  campoObjeto.value = "";
  resultadoObjeto.hidden = true;
  listaTabelasObjeto.innerHTML = "";
  definirStatus(statusObjeto, "");
  objetoAtualId = null;
  sugestoesObjeto.hidden = true;
  campoObjeto.focus();
});

btnExportarTodos.addEventListener("click", () => {
  // Sem 'tabelas', exporta todos os objetos. so_cadeia: só a aba "Cadeia completa".
  exportarArquivo(
    "xlsx",
    { nome: `Objetos-${carimboArquivo()}.xlsx`, so_cadeia: true },
    statusObjeto
  );
});

/* === Pesquisar por módulo / rotina === */
const campoRotina = el("campo-rotina");
const sugestoesRotina = el("sugestoes-rotina");
const btnPesquisarRotina = el("btn-pesquisar-rotina");
const btnLimparRotina = el("btn-limpar-rotina");
const btnExportarRotina = el("btn-exportar-rotina");
const statusRotina = el("status-rotina");
const resultadoRotina = el("resultado-rotina");
const listaRotinas = el("lista-rotinas");

/* Nomes de tabela do último resultado, para o botão de exportar. */
let tabelasResultadoRotina = [];
let timerSugRotina = null;

/* Sugestões enquanto digita: lista rotinas com o módulo, e ao escolher já
   dispara a busca por id exato daquela rotina. */
campoRotina.addEventListener("input", () => {
  const termo = campoRotina.value.trim();
  if (termo.length < 2) { sugestoesRotina.hidden = true; return; }
  clearTimeout(timerSugRotina);
  timerSugRotina = setTimeout(() => buscarSugestoesRotina(termo), 250);
});
campoRotina.addEventListener("blur", () => {
  setTimeout(() => { sugestoesRotina.hidden = true; }, 200);
});

async function buscarSugestoesRotina(termo) {
  try {
    const d = await chamar(`/api/sugerir-rotinas?q=${encodeURIComponent(termo)}`);
    if (!d.sugestoes.length) { sugestoesRotina.hidden = true; return; }
    sugestoesRotina.innerHTML = d.sugestoes
      .map((s) =>
        `<div class="sugestao-item" data-id="${s.id}" data-nome="${escaparHtml(s.rotina)}">` +
        `<span class="sugestao-id">#${s.id}</span>` +
        `<span class="sugestao-desc">${escaparHtml(s.rotina)} · <em>${escaparHtml(s.modulo)}</em></span></div>`
      )
      .join("");
    sugestoesRotina.hidden = false;
    sugestoesRotina.querySelectorAll(".sugestao-item").forEach((item) => {
      item.addEventListener("mousedown", (ev) => {
        ev.preventDefault();
        const id = parseInt(item.dataset.id, 10);
        campoRotina.value = item.dataset.nome;
        sugestoesRotina.hidden = true;
        pesquisarRotina(id);
      });
    });
  } catch {
    sugestoesRotina.hidden = true;
  }
}

function escaparHtml(s) {
  return String(s ?? "").replace(/[&<>"]/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
}

async function pesquisarRotina(idExato) {
  const limite = el("campo-limite-rotina")?.value || "20";
  let url;
  if (Number.isInteger(idExato)) {
    url = `/api/buscar-por-rotina?id=${idExato}&limite=${limite}`;
  } else {
    const termo = campoRotina.value.trim();
    if (termo.length < 2) {
      definirStatus(statusRotina, "Digite ao menos 2 caracteres.", "status-erro");
      return;
    }
    url = `/api/buscar-por-rotina?q=${encodeURIComponent(termo)}&limite=${limite}`;
  }
  definirStatus(statusRotina, "Pesquisando...", "status-trabalhando");

  try {
    const d = await chamar(url);
    renderRotinas(d.rotinas);
    // Junta os nomes de tabela do resultado, sem repetir, para o export.
    const nomes = new Set();
    (d.rotinas || []).forEach((r) =>
      r.objetos.forEach((o) => o.tabelas.forEach((t) => nomes.add(t.nome)))
    );
    tabelasResultadoRotina = [...nomes];
    btnExportarRotina.hidden = tabelasResultadoRotina.length === 0;

    resultadoRotina.hidden = false;
    definirStatus(
      statusRotina,
      d.total ? `${d.total} rotina(s) · ${tabelasResultadoRotina.length} tabela(s)` : "Nenhuma rotina encontrada",
      d.total ? "status-ok" : "status-trabalhando"
    );
    resultadoRotina.scrollIntoView({ behavior: "smooth", block: "start" });
  } catch (e) {
    definirStatus(statusRotina, e.message, "status-erro");
  }
}

function renderRotinas(rotinas) {
  if (!rotinas || !rotinas.length) {
    listaRotinas.innerHTML = "<p class='ajuda'>Nenhuma rotina bateu com o termo.</p>";
    return;
  }

  listaRotinas.innerHTML = rotinas
    .map((r) => {
      const objetosHtml = r.objetos.length
        ? r.objetos
            .map((o) => {
              const tabs = o.tabelas
                .map(
                  (t) =>
                    `<li>
                      <span class="tabela-nome">${escaparHtml(t.nome)}</span>
                      ${t.codigo != null ? `<span class="tabela-codigo">#${t.codigo}</span>` : ""}
                      <span class="tabela-meta">${numero(t.qtd_campos || 0)} campos${t.prefixo ? ` · ${escaparHtml(t.prefixo)}_` : ""}</span>
                      ${t.descricao_tabela ? `<div class="tabela-descricao">${escaparHtml(t.descricao_tabela)}</div>` : ""}
                    </li>`
                )
                .join("");
              return `<div class="rotina-objeto">
                  <div class="tabela-objetos">Objeto <span class="tag-objeto">${o.id} — ${escaparHtml(o.descricao || "sem descrição")}</span></div>
                  <ul class="lista-tabelas">${tabs}</ul>
                </div>`;
            })
            .join("")
        : "<p class='ajuda'>Esta rotina não tem tabelas mapeadas (objetos sem tabela própria).</p>";

      return `<div class="cartao-rotina">
        <div class="tabela-cabecalho">
          <span class="tabela-nome">${escaparHtml(r.rotina || "(rotina sem nome)")}</span>
          <span class="tabela-codigo">rotina #${r.rotina_id}</span>
        </div>
        <div class="tabela-meta">Módulo: ${escaparHtml(r.modulo || "—")}${r.modulo_id ? ` (#${r.modulo_id})` : ""}</div>
        ${objetosHtml}
      </div>`;
    })
    .join("");
}

btnPesquisarRotina.addEventListener("click", () => pesquisarRotina());
campoRotina.addEventListener("keydown", (ev) => {
  if (ev.key === "Enter") { ev.preventDefault(); sugestoesRotina.hidden = true; pesquisarRotina(); }
});
btnLimparRotina.addEventListener("click", () => {
  campoRotina.value = "";
  resultadoRotina.hidden = true;
  listaRotinas.innerHTML = "";
  tabelasResultadoRotina = [];
  btnExportarRotina.hidden = true;
  sugestoesRotina.hidden = true;
  definirStatus(statusRotina, "");
  campoRotina.focus();
});

btnExportarRotina.addEventListener("click", () => {
  if (!tabelasResultadoRotina.length) return;
  exportarArquivo(
    "xlsx",
    { tabelas: tabelasResultadoRotina, nome: `Rotina-${carimboArquivo()}.xlsx` },
    statusRotina
  );
});

/* ---------------------------------------------------------------- start */

/* Tema toggle */
const btnTema = el("btn-tema");
btnTema.addEventListener("click", () => {
  const claro = document.documentElement.getAttribute("data-tema") === "claro";
  if (claro) {
    document.documentElement.removeAttribute("data-tema");
    localStorage.setItem("comandosdml.tema", "escuro");
    btnTema.innerHTML = "&#9790;"; // lua
    btnTema.title = "Mudar para tema claro";
  } else {
    document.documentElement.setAttribute("data-tema", "claro");
    localStorage.setItem("comandosdml.tema", "claro");
    btnTema.innerHTML = "&#9728;"; // sol
    btnTema.title = "Mudar para tema escuro";
  }
});
// Ajusta ícone inicial
if (document.documentElement.getAttribute("data-tema") === "claro") {
  btnTema.innerHTML = "&#9728;";
  btnTema.title = "Mudar para tema escuro";
} else {
  btnTema.title = "Mudar para tema claro";
}

/* Botão de encerrar a ferramenta: pede confirmação, chama o servidor para se
   desligar e avisa que a aba pode ser fechada. */
const btnEncerrar = el("btn-encerrar");
btnEncerrar.addEventListener("click", async () => {
  const ok = window.confirm(
    "Encerrar o servidor da ferramenta?\n\n" +
    "A tela vai parar de funcionar. Para usar de novo, abra pelo atalho " +
    '"ABRIR ComandosDml" (ou iniciar-porta.bat).'
  );
  if (!ok) return;

  btnEncerrar.disabled = true;
  try {
    await chamar("/api/encerrar", { method: "POST" });
  } catch {
    // O servidor pode derrubar a conexão antes de responder: isso é esperado.
  }
  // A partir daqui o servidor está saindo. Mostra o painel de offline, que já
  // existe e explica como religar. Ele serve de fallback caso a janela não
  // feche sozinha (alguns navegadores bloqueiam window.close()).
  document.body.innerHTML =
    '<div style="max-width:640px;margin:4rem auto;padding:2rem;font-family:system-ui,sans-serif;line-height:1.5">' +
    '<h1 style="font-size:1.4rem">Ferramenta encerrada</h1>' +
    "<p>O servidor local foi desligado. Esta janela vai fechar sozinha.</p>" +
    '<p>Para usar de novo, dê duplo clique no atalho <strong>"2 - ABRIR ComandosDml.bat"</strong> ' +
    "(ou <code>iniciar-porta.bat</code>) na pasta da ferramenta.</p>" +
    "</div>";

  // Tenta fechar a janela automaticamente. Em janela aberta pelo Edge em modo
  // --app (janela dedicada da ferramenta) o window.close() costuma funcionar.
  // Fechar a janela NÍO afeta a reabertura: o atalho sobe um novo processo.
  const fechar = () => {
    try { window.close(); } catch { /* ignora */ }
    // Alguns ambientes só fecham via window.open(..).close() sobre a própria
    // janela; tentativa extra como reforço.
    try { window.open("", "_self"); window.close(); } catch { /* ignora */ }
  };
  // Pequeno atraso para a mensagem aparecer e a resposta HTTP concluir.
  setTimeout(fechar, 400);
});

/* === Índices x Relações: interpretar erro === */
const campoErro = el("campo-erro");
const btnAnalisarErro = el("btn-analisar-erro");
const btnLimparErro = el("btn-limpar-erro");
const btnCopiarErro = el("btn-copiar-erro");
const statusErroAnalise = el("status-erro-analise");
const caixaErro = el("caixa-erro");
const saidaErro = el("saida-erro");
const tabelasErro = el("tabelas-erro");
let scriptErroAtual = "";

autoCrescer(campoErro);  // textarea cresce conforme a mensagem de erro colada

btnAnalisarErro.addEventListener("click", async () => {
  const erro = campoErro.value.trim();
  if (erro.length < 10) {
    definirStatus(statusErroAnalise, "Cole a mensagem de erro completa.", "status-erro");
    return;
  }
  btnAnalisarErro.disabled = true;
  definirStatus(statusErroAnalise, "Interpretando o erro...", "status-trabalhando");
  try {
    const d = await chamar("/api/analisar-erro", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ erro }),
    });
    scriptErroAtual = d.interpretacao || d.texto;
    saidaErro.textContent = scriptErroAtual;
    caixaErro.hidden = false;
    btnCopiarErro.disabled = false;
    tabelasErro.textContent = d.tabelas && d.tabelas.length
      ? `· tabela(s): ${d.tabelas.join(", ")}`
      : "· nenhuma tabela identificada no erro";
    definirStatus(statusErroAnalise, "Interpretação concluída.", "status-ok");
    setTimeout(() => caixaErro.scrollIntoView({ behavior: "smooth", block: "start" }), 60);
  } catch (e) {
    definirStatus(statusErroAnalise, e.message || "falha ao gerar", "status-erro");
  } finally {
    btnAnalisarErro.disabled = false;
  }
});

btnCopiarErro.addEventListener("click", () => {
  copiar(scriptErroAtual, btnCopiarErro);
  caixaErro.scrollIntoView({ behavior: "smooth", block: "start" });
});

btnLimparErro.addEventListener("click", () => {
  campoErro.value = "";
  campoErro.style.height = "";   // volta à altura inicial
  caixaErro.hidden = true;
  saidaErro.textContent = "";
  scriptErroAtual = "";
  btnCopiarErro.disabled = true;
  definirStatus(statusErroAnalise, "");
  campoErro.focus();
});

/* === Montar comando: fluxo guiado por passos (sem IA) ===
   Passos: 1) tipo  2) tabelas (JOIN só por relação real)  3) campos pelo
   literal  4) filtros/valores  5) gerar. Suporta INSERT com valores ou
   INSERT...SELECT com pareamento destino<-origem. */
(function initMontadorGuiado() {
  const areaTipos = el("montar-tipos");
  if (!areaTipos) return;

  // --- elementos dos passos ---
  const buscaTabela = el("montar-tabela-busca");
  const sugTabela = el("montar-tabela-sugestoes");
  const listaTabelas = el("montar-tabelas-lista");
  const dicaTabelas = el("montar-tabelas-dica");
  const msgTabelas = el("montar-tabelas-msg");
  const rotuloPassoTab = el("rotulo-passo-tabelas");
  const ajudaPassoTab = el("ajuda-passo-tabelas");

  const rotuloPassoCampos = el("rotulo-passo-campos");
  const areaCampos = el("montar-campos-area");

  const rotuloPassoDados = el("rotulo-passo-dados");
  const areaDados = el("montar-dados-area");

  const modoSelectBox = el("montar-modo-select");
  const areaModos = el("montar-modos");
  const modoAjuda = el("montar-modo-ajuda");
  const passoUnion = el("passo-union");
  const unionBlocosArea = el("union-blocos");
  const btnAddBloco = el("btn-add-bloco");
  const areaBancos = el("montar-bancos");
  const btnGerar = el("btn-montar-gerar");
  const btnCopiar = el("btn-montar-copiar");
  const btnLimpar = el("btn-montar-limpar");
  const statusMontar = el("montar-status");
  const avisoMontar = el("montar-aviso");
  const saidaMontar = el("montar-saida");

  // Condições amigáveis. 'v' é o valor enviado ao backend (não muda); 'rot' é
  // o texto exibido, com o operador SQL entre parênteses; 'precisa' = quantos
  // valores a condição exige (0, 1 ou 2).
  const CONDICOES = [
    { v: "igual a", rot: "Igual (=)", precisa: 1 },
    { v: "diferente de", rot: "Diferente (<>)", precisa: 1 },
    { v: "começa com", rot: "Começa com (LIKE)", precisa: 1 },
    { v: "termina com", rot: "Termina com (LIKE)", precisa: 1 },
    { v: "contém", rot: "Contém (LIKE)", precisa: 1 },
    { v: "não contém", rot: "Não contém (NOT LIKE)", precisa: 1 },
    { v: "maior que", rot: "Maior que (>)", precisa: 1 },
    { v: "maior ou igual", rot: "Maior ou igual (>=)", precisa: 1 },
    { v: "menor que", rot: "Menor que (<)", precisa: 1 },
    { v: "menor ou igual", rot: "Menor ou igual (<=)", precisa: 1 },
    { v: "está entre", rot: "Está entre (BETWEEN)", precisa: 2 },
    { v: "está na lista", rot: "Está na lista (IN)", precisa: 1 },
    { v: "não está na lista", rot: "Não está na lista (NOT IN)", precisa: 1 },
    { v: "está vazio", rot: "Está vazio (IS NULL)", precisa: 0 },
    { v: "não está vazio", rot: "Não está vazio (IS NOT NULL)", precisa: 0 },
  ];

  // --- estado do fluxo ---
  let tipo = "select";
  let banco = "oracle";   // oracle | sqlserver (passo 5)
  let modoSelect = "simples";   // simples (JOINs) | union (UNION ALL)
  // Blocos do UNION ALL: [{tabela, campos:[{nome,tipo,pk,descricao}],
  //   marcados:Set, filtros:[]}]
  let blocosUnion = [];
  // tabelas escolhidas: [{nome, campos:[{nome,tipo,pk,descricao}], relacoes:[...],
  //   origem: {tabela_origem, campo_origem, campo_destino} | null (base)}]
  let tabelas = [];
  const cacheTabela = {};   // nome -> dados de /api/campos-tabela

  function multi() { return tabelas.length > 1; }
  function base() { return tabelas[0] || null; }

  function qualif(nomeTabela, campo) {
    return multi() ? `${nomeTabela}.${campo}` : campo;
  }

  /* ============ PASSO 1: tipo ============ */
  areaTipos.querySelectorAll(".tipo-opcao").forEach((b) => {
    b.addEventListener("click", () => {
      if (b.dataset.tipo === tipo) return;   // já é o tipo atual
      areaTipos.querySelectorAll(".tipo-opcao").forEach((x) => x.classList.remove("ativo"));
      b.classList.add("ativo");
      tipo = b.dataset.tipo;
      // Trocar de tipo recomeça do zero: tabelas, campos, filtros e resultado.
      // Cada tipo de comando é um ponto de partida limpo.
      tabelas = [];
      filtros = [];
      setsUpdate = [];
      valoresInsert = [];
      paresInsert = [];
      fonteInsert = null;
      modoInsert = "valores";
      pendenteCross = null;
      modoSelect = "simples";
      blocosUnion = [];
      if (areaModos) areaModos.querySelectorAll(".modo-opcao").forEach((x) => x.classList.toggle("ativo", x.dataset.modo === "simples"));
      buscaTabela.value = "";
      listaTabelas.innerHTML = "";
      msgTabela("");
      atualizarRotulos();
      renderCampos();
      renderDados();
      atualizarDicaTabelas();
      limparSaida();
    });
  });

  // Seletor de modo da consulta (simples x UNION ALL).
  if (areaModos) {
    areaModos.querySelectorAll(".modo-opcao").forEach((b) => {
      b.addEventListener("click", () => {
        if (b.dataset.modo === modoSelect) return;
        areaModos.querySelectorAll(".modo-opcao").forEach((x) => x.classList.remove("ativo"));
        b.classList.add("ativo");
        modoSelect = b.dataset.modo;
        aplicarModoSelect();
        limparSaida();
      });
    });
  }

  /* ===== UNION ALL: blocos de consulta ===== */
  function novoBlocoUnion() {
    return { tabela: "", campos: [], marcados: [], filtros: [] };
  }

  function renderBlocosUnion() {
    if (!unionBlocosArea) return;
    unionBlocosArea.innerHTML = blocosUnion.map((b, i) => {
      const remover = blocosUnion.length > 2
        ? `<button type="button" class="chip-x" data-rembloco="${i}" title="remover consulta">&times;</button>` : "";
      const campos = b.campos.length
        ? `<div class="bloco-campos">` + b.campos.map((c) =>
            `<label class="campo-check"><input type="checkbox" class="chk-union" data-b="${i}" value="${escaparHtml(c.nome)}"${b.marcados.includes(c.nome) ? " checked" : ""}>` +
            `<span class="cc-nome">${escaparHtml(c.descricao || c.nome)}</span>` +
            `<span class="cc-tec">${escaparHtml(c.nome)}</span></label>`).join("") + `</div>`
        : (b.tabela ? `<p class="ajuda">Carregando campos...</p>` : "");
      const qtd = b.marcados.length;
      return `<div class="union-bloco" data-i="${i}">` +
        `<div class="union-bloco-cabec"><strong>Consulta ${i + 1}</strong>` +
        `<span class="union-qtd">${qtd} campo(s)</span>${remover}</div>` +
        `<div class="campo-tabela-add"><input type="text" class="union-busca" data-b="${i}" ` +
        `placeholder="tabela desta consulta" value="${escaparHtml(b.tabela)}">` +
        `<div class="sugestoes union-sug" data-b="${i}" hidden></div></div>` +
        campos + `</div>`;
    }).join("");
    ligarBlocosUnion();
    atualizarAvisoUnion();
  }

  let timerUnionBusca = null;
  function ligarBlocosUnion() {
    unionBlocosArea.querySelectorAll(".union-busca").forEach((inp) => {
      const bi = parseInt(inp.dataset.b, 10);
      const sug = unionBlocosArea.querySelector(`.union-sug[data-b="${bi}"]`);
      inp.addEventListener("input", () => {
        const termo = inp.value.trim();
        if (termo.length < 2) { sug.hidden = true; return; }
        clearTimeout(timerUnionBusca);
        timerUnionBusca = setTimeout(async () => {
          try {
            const d = await chamar(`/api/sugerir-tabelas?q=${encodeURIComponent(termo)}`);
            if (!d.sugestoes.length) { sug.hidden = true; return; }
            sug.innerHTML = d.sugestoes.map((s) =>
              `<div class="sugestao-item" data-nome="${s.nome}"><span class="sugestao-id">${s.nome}</span>` +
              `<span class="sugestao-desc">${s.campos} campos</span></div>`).join("");
            sug.hidden = false;
            sug.querySelectorAll(".sugestao-item").forEach((item) => {
              item.addEventListener("mousedown", async (ev) => {
                ev.preventDefault();
                sug.hidden = true;
                await definirTabelaBloco(bi, item.dataset.nome);
              });
            });
          } catch { sug.hidden = true; }
        }, 250);
      });
      inp.addEventListener("blur", () => setTimeout(() => { sug.hidden = true; }, 200));
    });
    unionBlocosArea.querySelectorAll(".chk-union").forEach((chk) => {
      chk.addEventListener("change", () => {
        const bi = parseInt(chk.dataset.b, 10);
        const b = blocosUnion[bi];
        if (chk.checked) { if (!b.marcados.includes(chk.value)) b.marcados.push(chk.value); }
        else { b.marcados = b.marcados.filter((x) => x !== chk.value); }
        atualizarAvisoUnion();
        // atualiza só a contagem no cabeçalho
        const cab = unionBlocosArea.querySelector(`.union-bloco[data-i="${bi}"] .union-qtd`);
        if (cab) cab.textContent = `${b.marcados.length} campo(s)`;
        limparSaida();
      });
    });
    unionBlocosArea.querySelectorAll("[data-rembloco]").forEach((btn) => {
      btn.addEventListener("click", () => {
        blocosUnion.splice(parseInt(btn.dataset.rembloco, 10), 1);
        renderBlocosUnion(); limparSaida();
      });
    });
  }

  async function definirTabelaBloco(bi, nome) {
    try {
      const d = await carregarTabela(nome);
      blocosUnion[bi].tabela = d.nome;
      blocosUnion[bi].campos = d.campos || [];
      blocosUnion[bi].marcados = [];
      renderBlocosUnion(); limparSaida();
    } catch (e) {
      msgTabela(e.message || "falha ao carregar tabela", "erro");
    }
  }

  // Aviso de validação do UNION: todas as consultas com a mesma qtd de campos.
  function atualizarAvisoUnion() {
    const comTab = blocosUnion.filter((b) => b.tabela && b.marcados.length);
    if (comTab.length < 2) return;
    const qtds = comTab.map((b) => b.marcados.length);
    const iguais = qtds.every((q) => q === qtds[0]);
    if (!iguais) {
      msgTabela(`As consultas precisam ter a MESMA quantidade de campos. Agora: ${qtds.join(", ")}.`, "aviso");
    } else {
      msgTabela("");
    }
  }

  if (btnAddBloco) {
    btnAddBloco.addEventListener("click", () => {
      blocosUnion.push(novoBlocoUnion());
      renderBlocosUnion(); limparSaida();
    });
  }

  // Seletor de banco (passo 5).
  areaBancos.querySelectorAll(".banco-opcao").forEach((b) => {
    b.addEventListener("click", () => {
      areaBancos.querySelectorAll(".banco-opcao").forEach((x) => x.classList.remove("ativo"));
      b.classList.add("ativo");
      banco = b.dataset.banco;
      limparSaida();   // o SQL anterior pode ter formato de data do outro banco
    });
  });

  function atualizarRotulos() {
    const mapa = {
      select: { tab: "Em quais tabelas consultar?", ajuda: "Comece pela tabela principal; depois dá para juntar outras que tenham relação.", campos: "Quais campos mostrar?", dados: "Condições (cláusula WHERE) — opcional" },
      insert: { tab: "Em qual tabela inserir?", ajuda: "Escolha a tabela de destino do INSERT.", campos: "Como preencher os campos?", dados: "" },
      update: { tab: "Qual tabela alterar?", ajuda: "Escolha a tabela do UPDATE.", campos: "Quais campos alterar e para qual valor?", dados: "Quais registros alterar (cláusula WHERE) — obrigatório" },
      delete: { tab: "De qual tabela apagar?", ajuda: "Escolha a tabela do DELETE.", campos: "", dados: "Quais registros apagar (cláusula WHERE) — obrigatório" },
    };
    const m = mapa[tipo];
    rotuloPassoTab.textContent = m.tab;
    ajudaPassoTab.textContent = m.ajuda;
    rotuloPassoCampos.textContent = m.campos || "Campos";
    rotuloPassoDados.textContent = m.dados || "Filtrar";
    // passo campos some para DELETE
    el("passo-campos").hidden = (tipo === "delete");
    // O modo (simples/UNION) só aparece para SELECT.
    if (modoSelectBox) modoSelectBox.hidden = (tipo !== "select");
    aplicarModoSelect();
    // só SELECT permite multi-tabela (JOIN)
    atualizarDicaTabelas();
  }

  // Mostra/esconde o painel de UNION vs os passos normais, conforme o modo.
  function aplicarModoSelect() {
    const union = (tipo === "select" && modoSelect === "union");
    if (passoUnion) passoUnion.hidden = !union;
    // Esconde os passos 2, 3 e 4 normais quando em UNION.
    const passoTab = el("passo-tabelas");
    if (passoTab) passoTab.hidden = union;
    el("passo-campos").hidden = union || (tipo === "delete");
    el("passo-dados").hidden = union;
    if (modoAjuda) {
      modoAjuda.textContent = union
        ? "Empilha resultados de várias consultas (linhas somadas). Todas com a mesma quantidade de campos."
        : "Uma consulta, podendo juntar tabelas lado a lado por relação (JOIN).";
    }
    if (union && !blocosUnion.length) {
      // começa com dois blocos vazios (UNION precisa de ao menos dois)
      blocosUnion = [novoBlocoUnion(), novoBlocoUnion()];
      renderBlocosUnion();
    }
  }

  /* ============ PASSO 2: tabelas ============ */
  let timerBusca = null;
  buscaTabela.addEventListener("input", () => {
    const termo = buscaTabela.value.trim();
    if (termo.length < 2) { sugTabela.hidden = true; return; }
    clearTimeout(timerBusca);
    timerBusca = setTimeout(async () => {
      try {
        const d = await chamar(`/api/sugerir-tabelas?q=${encodeURIComponent(termo)}`);
        if (!d.sugestoes.length) { sugTabela.hidden = true; return; }
        sugTabela.innerHTML = d.sugestoes.map((s) =>
          `<div class="sugestao-item" data-nome="${s.nome}">` +
          `<span class="sugestao-id">${s.nome}</span>` +
          `<span class="sugestao-desc">${escaparHtml(s.descricao || s.assunto)} · ${s.campos} campos</span></div>`
        ).join("");
        sugTabela.hidden = false;
        sugTabela.querySelectorAll(".sugestao-item").forEach((item) => {
          item.addEventListener("mousedown", (ev) => {
            ev.preventDefault();
            buscaTabela.value = "";
            sugTabela.hidden = true;
            escolherTabela(item.dataset.nome);
          });
        });
      } catch { sugTabela.hidden = true; }
    }, 250);
  });
  buscaTabela.addEventListener("blur", () => setTimeout(() => { sugTabela.hidden = true; }, 200));

  async function carregarTabela(nome) {
    if (cacheTabela[nome]) return cacheTabela[nome];
    const d = await chamar(`/api/campos-tabela?nome=${encodeURIComponent(nome)}`);
    cacheTabela[nome] = d;
    return d;
  }

  // Escolhe uma tabela digitada na busca. Se é a primeira, vira a principal.
  // Se já há tabelas e a nova tem relação com alguma presente (SELECT), liga
  // automaticamente como JOIN encadeado, mostrando por quais campos.
  async function escolherTabela(nome) {
    try {
      const d = await carregarTabela(nome);

      // Primeira tabela, ou tipos que não aceitam multi-tabela: vira base.
      if (!base() || tipo !== "select") {
        tabelas = [{ nome: d.nome, campos: d.campos || [], relacoes: d.relacoes || [], eh_view: !!d.eh_view, origem: null }];
        msgTabela("");
        renderTabelas(); renderCampos(); renderDados(); atualizarDicaTabelas(); limparSaida();
        return;
      }

      // Já tem tabela(s): se a nova já está no comando, ignora.
      if (tabelas.some((t) => t.nome.toLowerCase() === d.nome.toLowerCase())) {
        msgTabela(`${d.nome} já está no comando.`, "aviso");
        return;
      }

      // Procura uma relação entre a nova tabela e QUALQUER tabela já escolhida.
      let liga = await acharLigacao(d.nome);
      // VIEW não tem FK no dicionário. Se a nova tabela (ou alguma presente) é
      // view, tenta ligar por campo de MESMO SUFIXO (ex.: EJI_CdiContratado ↔
      // CON_CdiContratado) como INNER JOIN, em vez de cair no CROSS JOIN.
      if (!liga && (d.eh_view || tabelas.some((t) => t.eh_view))) {
        liga = ligarPorSufixo(d);
      }
      if (!liga) {
        // Sem relação: não dá para INNER/LEFT/RIGHT com segurança. Oferece
        // juntar como CROSS JOIN (produto cartesiano), que não usa relação.
        pendenteCross = { nome: d.nome, campos: d.campos || [], relacoes: d.relacoes || [], eh_view: !!d.eh_view };
        msgTabelaCross(d.nome);
        return;
      }
      tabelas.push({
        nome: d.nome, campos: d.campos || [], relacoes: d.relacoes || [], eh_view: !!d.eh_view,
        origem: {
          tabela_origem: liga.origem, campo_origem: liga.campo_origem,
          campo_destino: liga.campo_destino, tipo: "inner",
        },
      });
      renderTabelas(); renderCampos(); renderDados(); atualizarDicaTabelas(); limparSaida();
      // Confirmação curta e discreta (o detalhe do par fica no tooltip do chip
      // e no "ver ligações"). Some sozinha depois de alguns segundos.
      const via = liga.porSufixo ? ` (view, por ${liga.campo_origem} = ${liga.campo_destino})` : "";
      msgTabela(`✓ ${d.nome} ligada a ${liga.origem}${via}.`, "ok", true);
    } catch (e) {
      msgTabela(e.message || "falha ao carregar tabela", "erro");
    }
  }

  // Tabela sem relação pendente de confirmação como CROSS JOIN.
  let pendenteCross = null;

  // Mostra o aviso de "sem relação" com a opção de juntar como CROSS JOIN.
  function msgTabelaCross(nome) {
    if (!msgTabelas) return;
    clearTimeout(timerMsgTabela);
    msgTabelas.className = "tabelas-msg msg-aviso";
    msgTabelas.innerHTML =
      `${escaparHtml(nome)} não tem relação no dicionário com as tabelas já escolhidas. ` +
      `Você pode <button type="button" class="link-toggle" id="btn-cross">juntar mesmo assim como CROSS JOIN</button> ` +
      `(cruza todas as linhas — use com cuidado), ou escolher outra tabela.`;
    msgTabelas.hidden = false;
    const b = el("btn-cross");
    if (b) b.addEventListener("click", confirmarCross);
  }

  function confirmarCross() {
    if (!pendenteCross) return;
    const d = pendenteCross;
    const origem = base() ? base().nome : "";
    tabelas.push({
      nome: d.nome, campos: d.campos, relacoes: d.relacoes, eh_view: !!d.eh_view,
      origem: { tabela_origem: origem, campo_origem: "", campo_destino: "", tipo: "cross" },
    });
    pendenteCross = null;
    renderTabelas(); renderCampos(); renderDados(); atualizarDicaTabelas(); limparSaida();
    msgTabela(`✓ ${d.nome} juntada como CROSS JOIN.`, "ok", true);
  }

  // Mensagem logo acima da lista de tabelas (passo 2). classe = ok|aviso|erro.
  // auto=true some sozinha depois de alguns segundos (para confirmações).
  let timerMsgTabela = null;
  function msgTabela(texto, classe, auto) {
    if (!msgTabelas) return;
    clearTimeout(timerMsgTabela);
    if (!texto) { msgTabelas.hidden = true; msgTabelas.textContent = ""; return; }
    msgTabelas.textContent = texto;
    msgTabelas.className = "tabelas-msg" + (classe ? " msg-" + classe : "");
    msgTabelas.hidden = false;
    if (auto) {
      timerMsgTabela = setTimeout(() => { msgTabelas.hidden = true; }, 4000);
    }
  }

  // Acha uma ligação (par de campos) entre `novaTabela` e alguma já escolhida.
  // Olha os DOIS sentidos: a relação pode estar declarada na tabela presente
  // (presente -> nova) OU na tabela nova (nova -> presente, caso de tabela
  // filha como ConBeneficios -> Contratados). No JOIN, a "origem" é sempre uma
  // tabela já presente; quando a relação vem do lado da nova, invertemos o par.
  async function acharLigacao(novaTabela) {
    const alvo = novaTabela.toLowerCase();
    // 1) sentido direto: alguma tabela presente aponta para a nova.
    for (const t of tabelas) {
      const rels = await relacoesDe(t.nome);
      const achou = (rels || []).find((r) => r.tabela.toLowerCase() === alvo);
      if (achou && achou.campos && achou.campos[0]) {
        return {
          origem: t.nome,
          campo_origem: achou.campos[0].campo_origem,
          campo_destino: achou.campos[0].campo_destino,
        };
      }
    }
    // 2) sentido inverso: a nova tabela aponta para alguma já presente.
    const relsNova = await relacoesDe(novaTabela);
    for (const t of tabelas) {
      const achou = (relsNova || []).find((r) => r.tabela.toLowerCase() === t.nome.toLowerCase());
      if (achou && achou.campos && achou.campos[0]) {
        // A relação está na nova (nova.campo => presente.campo). Como a origem
        // do JOIN é a tabela presente, invertemos para presente.campo = nova.campo.
        return {
          origem: t.nome,
          campo_origem: achou.campos[0].campo_destino,  // campo na tabela presente
          campo_destino: achou.campos[0].campo_origem,  // campo na tabela nova
        };
      }
    }
    return null;
  }

  // Liga uma VIEW a uma tabela presente por campo de MESMO SUFIXO (a parte
  // após o '_'). Views não têm FK no dicionário, mas colunas de chave
  // compartilham o sufixo entre a view e a tabela de origem — ex.:
  // PagamentosView.EJI_CdiContratado ↔ Contratados.CON_CdiContratado.
  // Escolhe o MELHOR par por prioridade: PK da tabela presente > sufixo Cdi >
  // outros identificadores (Nui/Nus/Cos) > qualquer sufixo em comum.
  function ligarPorSufixo(d) {
    const sufixo = (nome) => {
      const i = (nome || "").indexOf("_");
      return i >= 0 ? nome.slice(i + 1).toLowerCase() : "";
    };
    // mapa sufixo -> {campo, pk} da nova tabela/view
    const mapaNova = {};
    for (const c of (d.campos || [])) {
      const s = sufixo(c.nome);
      if (s) mapaNova[s] = { campo: c.nome, pk: !!c.pk };
    }
    // Pontuação da ligação. A ligação SÓ é confiável quando o sufixo em comum
    // é a CHAVE de uma das pontas (a PK). Casar por um Cdi acessório (ex.:
    // CdiTipoEndereco) ou por texto gera JOIN furado — por isso recebe nota
    // baixa e não liga automaticamente.
    const pontos = (campoPresente, pkPresente, infoNova) => {
      if (pkPresente || (infoNova && infoNova.pk)) return 100;  // PK em uma ponta
      const s = sufixo(campoPresente);
      if (s.startsWith("cdi")) return 50;   // identificador acessório
      return 10;                            // qualquer sufixo (fraco)
    };
    let melhor = null;
    let melhorPonto = -1;
    for (const t of tabelas) {
      for (const c of (t.campos || [])) {
        const s = sufixo(c.nome);
        if (!s || !mapaNova[s]) continue;
        const p = pontos(c.nome, !!c.pk, mapaNova[s]);
        if (p > melhorPonto) {
          melhorPonto = p;
          melhor = {
            origem: t.nome,
            campo_origem: c.nome,            // campo na tabela presente
            campo_destino: mapaNova[s].campo, // campo na view (nova)
            porSufixo: true,
            chave: true,
          };
        }
      }
    }
    // Liga automaticamente só com par FORTE (a PK de uma das pontas). Pares
    // fracos devolvem null → o fluxo oferece CROSS JOIN / escolha manual.
    if (melhor && melhorPonto >= 100) return melhor;
    return null;
  }

  const TIPOS_JOIN = [
    { v: "inner", r: "INNER (só o que casa nas duas)" },
    { v: "left", r: "LEFT (tudo da esquerda)" },
    { v: "right", r: "RIGHT (tudo da direita)" },
    { v: "cross", r: "CROSS (cruza todas as linhas)" },
  ];

  function renderTabelas() {
    if (!tabelas.length) { listaTabelas.innerHTML = ""; return; }
    // Caminho compacto: chips só com o nome, ligados por seta. O tipo de JOIN
    // e o par de campos vão no tooltip e na área "ver ligações".
    const chips = tabelas.map((t, i) => {
      const tj = t.origem ? (t.origem.tipo || "inner").toUpperCase() : "";
      const titulo = t.origem
        ? (t.origem.tipo === "cross"
            ? `CROSS JOIN com ${t.origem.tabela_origem} (cruza todas as linhas)`
            : `${tj} JOIN com ${t.origem.tabela_origem} por ${t.origem.campo_origem} = ${t.origem.campo_destino}`)
        : "Tabela principal";
      const remover = i === 0 ? "" :
        `<button type="button" class="chip-x" data-rem="${i}" title="remover esta tabela">&times;</button>`;
      const classe = i === 0 ? "tab-chip principal" : "tab-chip ligada";
      const seta = i === 0 ? "" :
        `<span class="tab-seta" aria-hidden="true" title="${escaparHtml(tj)} JOIN">&rarr;</span>`;
      const selo = (i > 0 && t.origem && t.origem.tipo !== "inner")
        ? `<span class="tab-tipojoin">${escaparHtml(tj)}</span>` : "";
      return seta + `<span class="${classe}" title="${escaparHtml(titulo)}">` +
        `${selo}<span class="tab-nome">${escaparHtml(t.nome)}</span>${remover}</span>`;
    }).join("");

    // Área "ver ligações": por ligação, um seletor do tipo de JOIN e o par.
    const ligadas = tabelas.map((t, i) => ({ t, i })).filter((x) => x.t.origem);
    let resumoJoins = "";
    if (ligadas.length) {
      const linhas = ligadas.map(({ t, i }) => {
        const o = t.origem;
        const opts = TIPOS_JOIN.map((j) =>
          `<option value="${j.v}"${(o.tipo || "inner") === j.v ? " selected" : ""}>${escaparHtml(j.r)}</option>`).join("");
        const par = o.tipo === "cross"
          ? `<code>${escaparHtml(o.tabela_origem)} × ${escaparHtml(t.nome)}</code> (produto cartesiano)`
          : `<code>${escaparHtml(o.tabela_origem)}.${o.campo_origem} = ${escaparHtml(t.nome)}.${o.campo_destino}</code>`;
        return `<li><select class="sel-tipojoin" data-i="${i}">${opts}</select> ${escaparHtml(t.nome)}: ${par}</li>`;
      }).join("");
      resumoJoins = `<details class="joins-detalhe" open><summary>ligações (${ligadas.length}) — tipo de junção</summary>` +
        `<ul class="joins-lista">${linhas}</ul></details>`;
    }

    listaTabelas.innerHTML = `<div class="tab-caminho">${chips}</div>${resumoJoins}`;
    listaTabelas.querySelectorAll(".chip-x").forEach((b) => {
      b.addEventListener("click", () => removerTabela(parseInt(b.dataset.rem, 10)));
    });
    listaTabelas.querySelectorAll(".sel-tipojoin").forEach((sel) => {
      sel.addEventListener("change", () => {
        const i = parseInt(sel.dataset.i, 10);
        if (tabelas[i] && tabelas[i].origem) {
          tabelas[i].origem.tipo = sel.value;
          renderTabelas(); limparSaida();
        }
      });
    });
  }

  function removerTabela(i) {
    const alvo = tabelas[i];
    if (!alvo) return;
    // remove dependentes (origem = alvo.nome) em cascata
    const nomes = new Set([alvo.nome.toLowerCase()]);
    let mudou = true;
    while (mudou) {
      mudou = false;
      for (const t of tabelas) {
        if (t.origem && nomes.has(t.origem.tabela_origem.toLowerCase()) && !nomes.has(t.nome.toLowerCase())) {
          nomes.add(t.nome.toLowerCase()); mudou = true;
        }
      }
    }
    tabelas = tabelas.filter((t) => !nomes.has(t.nome.toLowerCase()));
    renderTabelas(); renderCampos(); renderDados(); atualizarDicaTabelas(); limparSaida();
  }

  // Cadeia de JOINs em dois níveis: o usuário escolhe DE QUAL tabela já
  // presente partir e, então, qual tabela relacionada juntar. Isso permite
  // encadear: Contratados -> Folhas -> Locais -> ...
  const cacheRelacionadas = {};   // nomeTabela -> [{destino, campos[], origem}]

  async function relacoesDe(nomeTabela) {
    if (cacheRelacionadas[nomeTabela]) return cacheRelacionadas[nomeTabela];
    try {
      const d = await chamar(`/api/relacionadas?tabela=${encodeURIComponent(nomeTabela)}`);
      cacheRelacionadas[nomeTabela] = d.relacionadas || [];
    } catch { cacheRelacionadas[nomeTabela] = []; }
    return cacheRelacionadas[nomeTabela];
  }

  // Dica dinâmica no passo 2: diz quantas tabelas ainda dá para juntar a partir
  // das já escolhidas. A ligação em si é feita pela própria busca de tabela
  // (escolherTabela/acharLigacao), então não há mais seletor de dois níveis.
  async function atualizarDicaTabelas() {
    if (!dicaTabelas) return;
    if (tipo !== "select" || tabelas.length === 0) {
      dicaTabelas.hidden = true;
      return;
    }
    const jaTem = new Set(tabelas.map((t) => t.nome.toLowerCase()));
    const possiveis = new Set();
    for (const t of tabelas) {
      const rels = await relacoesDe(t.nome);
      for (const r of (rels || [])) {
        if (!jaTem.has(r.tabela.toLowerCase())) possiveis.add(r.tabela.toLowerCase());
      }
    }
    if (possiveis.size) {
      dicaTabelas.textContent = `Dica: dá para juntar mais ${possiveis.size} tabela(s) com relação. É só digitar o nome na busca acima.`;
      dicaTabelas.hidden = false;
    } else {
      dicaTabelas.hidden = true;
    }
  }

  /* ============ PASSO 3: campos ============ */
  // SELECT: checkboxes de campos (por tabela). UPDATE/INSERT: campo + valor.
  function renderCampos() {
    if (!base()) { areaCampos.innerHTML = `<p class="ajuda">Escolha a tabela primeiro.</p>`; return; }
    if (tipo === "delete") { areaCampos.innerHTML = ""; return; }

    if (tipo === "select") {
      areaCampos.innerHTML =
        `<div class="campos-por-literal">` +
        `<label class="rotulo-mini" for="campos-digitados">Digite os campos pelo nome do sistema (separados por vírgula):</label>` +
        `<div class="literal-controles">` +
        `<input type="text" id="campos-digitados" placeholder="Ex.: Nome, Matrícula, Data de admissão">` +
        `<button type="button" class="botao botao-secundario botao-mini" id="btn-marcar-literais">Marcar</button>` +
        `</div>` +
        `<p class="ajuda" id="literal-resultado">Digite e clique em Marcar: a ferramenta acha o campo técnico e marca para você.</p>` +
        `</div>` +
        `<div id="campos-resumo" class="campos-resumo" hidden></div>` +
        `<div class="campos-lista-cabec">` +
        `<button type="button" class="link-toggle" id="btn-toggle-campos">Mostrar todos os campos</button>` +
        `</div>` +
        `<div id="campos-colapsavel" hidden>` +
        tabelas.map((t) => grupoCamposSelect(t)).join("") +
        `</div>`;
      areaCampos.querySelectorAll(".filtro-campos-grupo").forEach((inp) => {
        inp.addEventListener("input", () => filtrarGrupo(inp));
      });
      const btnMarcar = el("btn-marcar-literais");
      const campoDig = el("campos-digitados");
      btnMarcar.addEventListener("click", () => marcarPorLiteral(campoDig.value));
      campoDig.addEventListener("keydown", (ev) => {
        if (ev.key === "Enter") { ev.preventDefault(); marcarPorLiteral(campoDig.value); }
      });
      el("btn-toggle-campos").addEventListener("click", toggleListaCampos);
      // reflete mudanças manuais nos checkboxes no resumo
      areaCampos.querySelectorAll('.campo-check input[type="checkbox"]').forEach((chk) => {
        chk.addEventListener("change", atualizarResumoCampos);
      });
      atualizarResumoCampos();
      return;
    }
    if (tipo === "update") { renderCamposUpdate(); return; }
    if (tipo === "insert") { renderCamposInsert(); return; }
  }

  // Mostra/esconde a lista completa de campos (checkboxes). Compacta por padrão.
  function toggleListaCampos(forcar) {
    const area = el("campos-colapsavel");
    const btn = el("btn-toggle-campos");
    if (!area || !btn) return;
    const mostrar = typeof forcar === "boolean" ? forcar : area.hidden;
    area.hidden = !mostrar;
    btn.textContent = mostrar ? "Esconder a lista de campos" : "Mostrar todos os campos";
  }

  // Resumo compacto dos campos marcados (chips), com a lista recolhida.
  function atualizarResumoCampos() {
    const resumo = el("campos-resumo");
    if (!resumo) return;
    const marcados = [];
    areaCampos.querySelectorAll('.campo-check input[type="checkbox"]:checked').forEach((chk) => {
      const lb = chk.closest(".campo-check");
      const nome = lb ? lb.querySelector(".cc-nome").textContent : chk.value;
      marcados.push({ q: chk.value, nome });
    });
    if (!marcados.length) {
      resumo.hidden = true;
      resumo.innerHTML = "";
      return;
    }
    resumo.hidden = false;
    resumo.innerHTML = `<span class="resumo-rotulo">${marcados.length} campo(s) escolhido(s):</span>` +
      marcados.map((m) =>
        `<span class="campo-chip">${escaparHtml(m.nome)}<button type="button" class="chip-x" data-desmarcar="${escaparHtml(m.q)}" title="tirar">&times;</button></span>`
      ).join("");
    resumo.querySelectorAll("[data-desmarcar]").forEach((b) => {
      b.addEventListener("click", () => {
        const alvo = b.dataset.desmarcar;
        areaCampos.querySelectorAll('.campo-check input[type="checkbox"]').forEach((chk) => {
          if (chk.value === alvo) chk.checked = false;
        });
        atualizarResumoCampos();
      });
    });
  }

  // Tira acentos e baixa a caixa, para comparar literais com tolerância.
  function semAcento(s) {
    return (s || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
  }

  // Interpreta os literais digitados e marca os checkboxes correspondentes.
  // Casa por: literal exato, literal que contém o texto, ou nome técnico.
  function marcarPorLiteral(texto) {
    const termos = (texto || "").split(",").map((t) => t.trim()).filter(Boolean);
    const resultado = el("literal-resultado");
    if (!termos.length) {
      if (resultado) { resultado.textContent = "Digite ao menos um campo."; resultado.className = "ajuda status-erro"; }
      return;
    }
    // índice de todos os campos de todas as tabelas escolhidas
    const todos = [];
    for (const t of tabelas) {
      for (const c of t.campos) {
        todos.push({ tab: t.nome, nome: c.nome, descricao: c.descricao || "",
          q: qualif(t.nome, c.nome),
          litNorm: semAcento(c.descricao || ""), tecNorm: semAcento(c.nome) });
      }
    }
    const achados = [];
    const naoAchados = [];
    for (const termo of termos) {
      const alvo = semAcento(termo);
      // 1) literal exato  2) técnico exato  3) literal contém  4) técnico contém
      let m = todos.find((c) => c.litNorm && c.litNorm === alvo)
           || todos.find((c) => c.tecNorm === alvo)
           || todos.find((c) => c.litNorm && c.litNorm.includes(alvo))
           || todos.find((c) => c.tecNorm.includes(alvo));
      if (m) achados.push(m); else naoAchados.push(termo);
    }
    // marca os checkboxes
    const marcadosAgora = new Set(achados.map((a) => a.q));
    areaCampos.querySelectorAll('.campo-check input[type="checkbox"]').forEach((chk) => {
      if (marcadosAgora.has(chk.value)) {
        chk.checked = true;
        // garante visível mesmo com filtro de grupo aplicado
        const lb = chk.closest(".campo-check");
        if (lb) lb.style.display = "";
      }
    });
    if (resultado) {
      const okTxt = achados.length ? `${achados.length} campo(s) marcado(s)` : "nenhum campo encontrado";
      const faltaTxt = naoAchados.length ? ` · não encontrei: ${naoAchados.join(", ")}` : "";
      resultado.textContent = okTxt + faltaTxt;
      resultado.className = "ajuda " + (naoAchados.length ? "status-trabalhando" : "status-ok");
    }
    // Mantém a lista grande recolhida e mostra só o resumo dos marcados.
    toggleListaCampos(false);
    atualizarResumoCampos();
  }

  function grupoCamposSelect(t) {
    const linhas = t.campos.map((c) => {
      const q = qualif(t.nome, c.nome);
      const rotulo = c.descricao ? escaparHtml(c.descricao) : c.nome;
      return `<label class="campo-check" data-busca="${(c.descricao + ' ' + c.nome).toLowerCase()}">` +
        `<input type="checkbox" value="${q}" data-tipo="${escaparHtml(c.tipo)}">` +
        `<span class="cc-nome">${rotulo}</span>` +
        `<span class="cc-tec">${c.nome}${c.pk ? " · PK" : ""}</span></label>`;
    }).join("");
    const titulo = multi() ? `<h4 class="grupo-titulo">${escaparHtml(t.nome)}</h4>` : "";
    return `<div class="campos-grupo" data-tab="${escaparHtml(t.nome)}">${titulo}` +
      `<input type="text" class="filtro-campos-grupo" placeholder="filtrar campos de ${escaparHtml(t.nome)}...">` +
      `<div class="campos-check-lista">${linhas}</div></div>`;
  }

  function filtrarGrupo(inp) {
    const grupo = inp.closest(".campos-grupo");
    const f = inp.value.toLowerCase();
    grupo.querySelectorAll(".campo-check").forEach((lb) => {
      lb.style.display = (!f || lb.dataset.busca.includes(f)) ? "" : "none";
    });
  }

  // UPDATE: usuário escolhe campos a alterar + valor. Com um seletor de campo.
  let setsUpdate = [];   // [{campo, tipo, valor}]
  function renderCamposUpdate() {
    if (!setsUpdate.length) setsUpdate = [{ campo: "", tipo: "", valor: "" }];
    const opts = optionsCampos(base());
    areaCampos.innerHTML =
      `<p class="ajuda">Escolha o campo e digite o novo valor. Pode alterar vários.</p>` +
      setsUpdate.map((s, i) =>
        `<div class="linha-par" data-i="${i}">` +
        `<select class="sel-campo-set">${opts}</select>` +
        `<span class="par-seta">=</span>` +
        `<input type="text" class="val-set" placeholder="novo valor" value="${escaparHtml(s.valor)}">` +
        (setsUpdate.length > 1 ? `<button type="button" class="chip-x" data-remset="${i}">&times;</button>` : "") +
        `</div>`
      ).join("") +
      `<button type="button" class="botao botao-secundario botao-mini" id="btn-add-set">+ outro campo</button>`;
    // set valores atuais nos selects
    areaCampos.querySelectorAll(".linha-par").forEach((div) => {
      const i = parseInt(div.dataset.i, 10);
      div.querySelector(".sel-campo-set").value = setsUpdate[i].campo || "";
    });
    ligarUpdate();
  }
  function ligarUpdate() {
    areaCampos.querySelectorAll(".sel-campo-set").forEach((sel) => {
      sel.addEventListener("change", () => {
        const i = parseInt(sel.closest(".linha-par").dataset.i, 10);
        setsUpdate[i].campo = sel.value;
        setsUpdate[i].tipo = sel.selectedOptions[0]?.dataset.tipo || "";
      });
    });
    areaCampos.querySelectorAll(".val-set").forEach((inp) => {
      inp.addEventListener("input", () => {
        const i = parseInt(inp.closest(".linha-par").dataset.i, 10);
        setsUpdate[i].valor = inp.value;
      });
    });
    areaCampos.querySelectorAll("[data-remset]").forEach((b) => {
      b.addEventListener("click", () => {
        setsUpdate.splice(parseInt(b.dataset.remset, 10), 1); renderCamposUpdate();
      });
    });
    const add = el("btn-add-set");
    if (add) add.addEventListener("click", () => { setsUpdate.push({ campo: "", tipo: "", valor: "" }); renderCamposUpdate(); });
  }

  // INSERT: dois modos — valores literais OU a partir de um SELECT (pareamento).
  let modoInsert = "valores";   // 'valores' | 'select'
  let valoresInsert = [];       // [{campo, tipo, valor}]
  let fonteInsert = null;       // {nome, campos, relacoes}
  let paresInsert = [];         // [{destino, origem}]
  function renderCamposInsert() {
    areaCampos.innerHTML =
      `<div class="insert-modo">` +
      `<label><input type="radio" name="modo-insert" value="valores" ${modoInsert === "valores" ? "checked" : ""}> Informar valores</label>` +
      `<label><input type="radio" name="modo-insert" value="select" ${modoInsert === "select" ? "checked" : ""}> Copiar de outra consulta (INSERT...SELECT)</label>` +
      `</div><div id="insert-corpo"></div>`;
    areaCampos.querySelectorAll('input[name="modo-insert"]').forEach((r) => {
      r.addEventListener("change", () => { modoInsert = r.value; renderInsertCorpo(); });
    });
    renderInsertCorpo();
  }
  function renderInsertCorpo() {
    const corpo = el("insert-corpo");
    if (modoInsert === "valores") {
      if (!valoresInsert.length) valoresInsert = [{ campo: "", tipo: "", valor: "" }];
      const opts = optionsCampos(base());
      corpo.innerHTML =
        `<p class="ajuda">Escolha cada campo e informe o valor a inserir. ` +
        `Ou clique em <strong>Incluir todos os campos</strong> para listar a tabela inteira e preencher só os valores.</p>` +
        `<div class="insert-atalhos">` +
        `<button type="button" class="botao botao-secundario botao-mini" id="btn-todos-campos">Incluir todos os campos</button>` +
        `<button type="button" class="botao botao-secundario botao-mini" id="btn-limpar-ins">Limpar lista</button>` +
        `</div>` +
        valoresInsert.map((v, i) =>
          `<div class="linha-par" data-i="${i}">` +
          `<select class="sel-campo-ins">${opts}</select>` +
          `<span class="par-seta">=</span>` +
          `<input type="text" class="val-ins" placeholder="valor" value="${escaparHtml(v.valor)}">` +
          (valoresInsert.length > 1 ? `<button type="button" class="chip-x" data-remins="${i}">&times;</button>` : "") +
          `</div>`
        ).join("") +
        `<button type="button" class="botao botao-secundario botao-mini" id="btn-add-ins">+ outro campo</button>`;
      corpo.querySelectorAll(".linha-par").forEach((div) => {
        const i = parseInt(div.dataset.i, 10);
        div.querySelector(".sel-campo-ins").value = valoresInsert[i].campo || "";
      });
      corpo.querySelectorAll(".sel-campo-ins").forEach((sel) => {
        sel.addEventListener("change", () => {
          const i = parseInt(sel.closest(".linha-par").dataset.i, 10);
          valoresInsert[i].campo = sel.value;
          valoresInsert[i].tipo = sel.selectedOptions[0]?.dataset.tipo || "";
        });
      });
      corpo.querySelectorAll(".val-ins").forEach((inp) => {
        inp.addEventListener("input", () => {
          const i = parseInt(inp.closest(".linha-par").dataset.i, 10);
          valoresInsert[i].valor = inp.value;
        });
      });
      corpo.querySelectorAll("[data-remins]").forEach((b) => {
        b.addEventListener("click", () => { valoresInsert.splice(parseInt(b.dataset.remins, 10), 1); renderInsertCorpo(); });
      });
      el("btn-add-ins").addEventListener("click", () => { valoresInsert.push({ campo: "", tipo: "", valor: "" }); renderInsertCorpo(); });
      el("btn-todos-campos").addEventListener("click", () => {
        // Lista todos os campos da tabela de destino, cada um numa linha,
        // com valor em branco para o usuário preencher. INSERT é sempre numa
        // só tabela, então usa base() (a principal).
        valoresInsert = base().campos.map((c) => ({ campo: c.nome, tipo: c.tipo, valor: "" }));
        renderInsertCorpo();
        definirStatus(statusMontar, `${valoresInsert.length} campo(s) adicionado(s). Preencha os valores que precisar e remova o resto.`, "status-ok");
      });
      el("btn-limpar-ins").addEventListener("click", () => {
        valoresInsert = [{ campo: "", tipo: "", valor: "" }];
        renderInsertCorpo();
      });
    } else {
      // INSERT...SELECT: escolher tabela de origem, depois parear destino<-origem
      corpo.innerHTML =
        `<p class="ajuda">Copia dados de uma consulta para esta tabela. Escolha de qual tabela vêm os dados e, para cada campo de destino, diga qual campo de origem o preenche (destino &larr; origem).</p>` +
        `<div class="campo-tabela-add"><input type="text" id="ins-fonte-busca" placeholder="De qual tabela copiar? (ex.: Contratados)"><div id="ins-fonte-sug" class="sugestoes" hidden></div></div>` +
        `<div id="ins-pares"></div>`;
      ligarBuscaFonte();
      renderParesInsert();
    }
  }
  let timerFonte = null;
  function ligarBuscaFonte() {
    const busca = el("ins-fonte-busca");
    const sug = el("ins-fonte-sug");
    busca.addEventListener("input", () => {
      const termo = busca.value.trim();
      if (termo.length < 2) { sug.hidden = true; return; }
      clearTimeout(timerFonte);
      timerFonte = setTimeout(async () => {
        try {
          const d = await chamar(`/api/sugerir-tabelas?q=${encodeURIComponent(termo)}`);
          if (!d.sugestoes.length) { sug.hidden = true; return; }
          sug.innerHTML = d.sugestoes.map((s) =>
            `<div class="sugestao-item" data-nome="${s.nome}"><span class="sugestao-id">${s.nome}</span>` +
            `<span class="sugestao-desc">${s.campos} campos</span></div>`).join("");
          sug.hidden = false;
          sug.querySelectorAll(".sugestao-item").forEach((item) => {
            item.addEventListener("mousedown", async (ev) => {
              ev.preventDefault();
              busca.value = item.dataset.nome; sug.hidden = true;
              fonteInsert = await carregarTabela(item.dataset.nome);
              paresInsert = [{ destino: "", origem: "" }];
              renderParesInsert();
            });
          });
        } catch { sug.hidden = true; }
      }, 250);
    });
    busca.addEventListener("blur", () => setTimeout(() => { sug.hidden = true; }, 200));
  }
  function renderParesInsert() {
    const area = el("ins-pares");
    if (!fonteInsert) { area.innerHTML = ""; return; }
    if (!paresInsert.length) paresInsert = [{ destino: "", origem: "" }];
    const optDest = optionsCamposLista(base().campos, false);
    const optOrig = optionsCamposLista(fonteInsert.campos, false);
    area.innerHTML =
      `<div class="pares-cabec"><span>Destino (${escaparHtml(base().nome)})</span><span></span><span>Origem (${escaparHtml(fonteInsert.nome)})</span></div>` +
      paresInsert.map((p, i) =>
        `<div class="linha-par par-triplo" data-i="${i}">` +
        `<select class="sel-dest">${optDest}</select>` +
        `<span class="par-seta">&larr;</span>` +
        `<select class="sel-orig">${optOrig}</select>` +
        (paresInsert.length > 1 ? `<button type="button" class="chip-x" data-rempar="${i}">&times;</button>` : "") +
        `</div>`
      ).join("") +
      `<button type="button" class="botao botao-secundario botao-mini" id="btn-add-par">+ outro par</button>`;
    area.querySelectorAll(".linha-par").forEach((div) => {
      const i = parseInt(div.dataset.i, 10);
      div.querySelector(".sel-dest").value = paresInsert[i].destino || "";
      div.querySelector(".sel-orig").value = paresInsert[i].origem || "";
    });
    area.querySelectorAll(".sel-dest").forEach((sel) => {
      sel.addEventListener("change", () => { paresInsert[parseInt(sel.closest(".linha-par").dataset.i, 10)].destino = sel.value; });
    });
    area.querySelectorAll(".sel-orig").forEach((sel) => {
      sel.addEventListener("change", () => { paresInsert[parseInt(sel.closest(".linha-par").dataset.i, 10)].origem = sel.value; });
    });
    area.querySelectorAll("[data-rempar]").forEach((b) => {
      b.addEventListener("click", () => { paresInsert.splice(parseInt(b.dataset.rempar, 10), 1); renderParesInsert(); });
    });
    el("btn-add-par").addEventListener("click", () => { paresInsert.push({ destino: "", origem: "" }); renderParesInsert(); });
  }

  function optionsCampos(t) {
    return optionsCamposLista(t.campos, multi() ? t.nome : "");
  }
  function optionsCamposLista(campos, prefixo) {
    const pre = prefixo ? prefixo + "." : "";
    return `<option value="">— escolha o campo —</option>` + campos.map((c) =>
      `<option value="${pre}${c.nome}" data-tipo="${escaparHtml(c.tipo)}">` +
      `${c.descricao ? escaparHtml(c.descricao) + " (" + c.nome + ")" : c.nome}</option>`).join("");
  }

  /* ============ PASSO 4: filtros / valores ============ */
  let filtros = [];   // [{campo, tipo, condicao, valor}]
  function renderDados() {
    if (!base()) { areaDados.innerHTML = `<p class="ajuda">Escolha a tabela primeiro.</p>`; return; }
    if (tipo === "insert" && modoInsert !== "select") {
      // INSERT por valores não tem WHERE
      areaDados.innerHTML = `<p class="ajuda">INSERT com valores não usa filtro.</p>`;
      el("passo-dados").hidden = false;
      return;
    }
    el("passo-dados").hidden = false;
    if (!filtros.length) filtros = [{ campo: "", tipo: "", condicao: "igual a", valor: "" }];
    const quais = (tipo === "insert" && modoInsert === "select") ? fonteInsert : base();
    const campos = (tipo === "insert" && modoInsert === "select")
      ? (fonteInsert ? fonteInsert.campos : [])
      : camposDeTodasTabelas();
    const opts = optionsCamposLista(campos, (tipo === "insert" && modoInsert === "select") ? "" : "");
    const obrig = (tipo === "update" || tipo === "delete");
    areaDados.innerHTML =
      `<p class="ajuda">${obrig ? "Pelo menos um filtro é obrigatório (segurança)." : "Adicione filtros ou deixe em branco para trazer tudo."}</p>` +
      filtros.map((f, i) => linhaFiltro(f, i, campos)).join("") +
      `<button type="button" class="botao botao-secundario botao-mini" id="btn-add-filtro">+ outro filtro</button>`;
    ligarFiltros(campos);
  }

  function camposDeTodasTabelas() {
    // para SELECT/UPDATE/DELETE: campos de todas as tabelas (qualificados se multi)
    const out = [];
    for (const t of tabelas) {
      for (const c of t.campos) {
        out.push({ nome: multi() ? `${t.nome}.${c.nome}` : c.nome, tipo: c.tipo, pk: c.pk, descricao: c.descricao });
      }
    }
    return out;
  }

  function linhaFiltro(f, i, campos) {
    const optsCampo = `<option value="">— campo —</option>` + campos.map((c) =>
      `<option value="${c.nome}" data-tipo="${escaparHtml(c.tipo)}">` +
      `${c.descricao ? escaparHtml(c.descricao) + " (" + c.nome + ")" : c.nome}</option>`).join("");
    const optsCond = CONDICOES.map((c) => `<option value="${c.v}">${escaparHtml(c.rot)}</option>`).join("");
    const juncao = i > 0 ? `<select class="fil-juncao"><option value="AND">E</option><option value="OR">OU</option></select>` : `<span class="fil-juncao-vazio"></span>`;
    return `<div class="linha-filtro" data-i="${i}">` + juncao +
      `<select class="fil-campo">${optsCampo}</select>` +
      `<select class="fil-cond">${optsCond}</select>` +
      `<input type="text" class="fil-valor" placeholder="valor">` +
      (filtros.length > 1 || i > 0 ? `<button type="button" class="chip-x" data-remfil="${i}">&times;</button>` : "") +
      `</div>`;
  }

  function ligarFiltros(campos) {
    areaDados.querySelectorAll(".linha-filtro").forEach((div) => {
      const i = parseInt(div.dataset.i, 10);
      const selCampo = div.querySelector(".fil-campo");
      const selCond = div.querySelector(".fil-cond");
      const inpVal = div.querySelector(".fil-valor");
      const selJun = div.querySelector(".fil-juncao");
      selCampo.value = filtros[i].campo || "";
      selCond.value = filtros[i].condicao || "igual a";
      inpVal.value = filtros[i].valor || "";
      if (selJun && filtros[i].juncao) selJun.value = filtros[i].juncao;
      ajustarValorPorCondicao(selCond.value, inpVal);
      selCampo.addEventListener("change", () => {
        filtros[i].campo = selCampo.value;
        filtros[i].tipo = selCampo.selectedOptions[0]?.dataset.tipo || "";
      });
      selCond.addEventListener("change", () => {
        filtros[i].condicao = selCond.value;
        ajustarValorPorCondicao(selCond.value, inpVal);
      });
      inpVal.addEventListener("input", () => { filtros[i].valor = inpVal.value; });
      if (selJun) selJun.addEventListener("change", () => { filtros[i].juncao = selJun.value; });
    });
    const add = el("btn-add-filtro");
    if (add) add.addEventListener("click", () => { filtros.push({ campo: "", tipo: "", condicao: "igual a", valor: "", juncao: "AND" }); renderDados(); });
    areaDados.querySelectorAll("[data-remfil]").forEach((b) => {
      b.addEventListener("click", () => { filtros.splice(parseInt(b.dataset.remfil, 10), 1); renderDados(); });
    });
  }

  function ajustarValorPorCondicao(cond, inpVal) {
    const def = CONDICOES.find((c) => c.v === cond);
    if (!def) return;
    if (def.precisa === 0) { inpVal.disabled = true; inpVal.placeholder = "(sem valor)"; inpVal.value = ""; }
    else if (def.precisa === 2) { inpVal.disabled = false; inpVal.placeholder = "ex.: 10 e 20"; }
    else { inpVal.disabled = false; inpVal.placeholder = cond === "está na lista" || cond === "não está na lista" ? "ex.: 1, 2, 3" : "valor"; }
  }

  /* ============ PASSO 5: gerar ============ */
  function coletarJoins() {
    return tabelas.filter((t) => t.origem).map((t) => ({
      tabela: t.nome,
      tabela_origem: t.origem.tabela_origem,
      campo_origem: t.origem.campo_origem,
      campo_destino: t.origem.campo_destino,
      tipo: t.origem.tipo || "inner",
    }));
  }
  function coletarFiltros() {
    return filtros.filter((f) => f.campo).map((f) => ({
      campo: f.campo, condicao: f.condicao, valor: f.valor, juncao: f.juncao || "AND",
    }));
  }
  function coletarCamposSelect() {
    const marcados = [];
    areaCampos.querySelectorAll('.campo-check input[type="checkbox"]:checked').forEach((chk) => marcados.push(chk.value));
    return marcados;
  }

  btnGerar.addEventListener("click", async () => {
    // Modo UNION ALL: monta a lista de blocos e envia.
    if (tipo === "select" && modoSelect === "union") {
      const blocos = blocosUnion
        .filter((b) => b.tabela && b.marcados.length)
        .map((b) => ({ tabela: b.tabela, campos: b.marcados.slice(), filtros: [], joins: [] }));
      if (blocos.length < 2) {
        definirStatus(statusMontar, "Monte pelo menos duas consultas com campos.", "status-erro");
        return;
      }
      const qtds = blocos.map((b) => b.campos.length);
      if (!qtds.every((q) => q === qtds[0])) {
        definirStatus(statusMontar, `As consultas precisam ter a mesma quantidade de campos (agora: ${qtds.join(", ")}).`, "status-erro");
        return;
      }
      definirStatus(statusMontar, "Gerando...", "status-trabalhando");
      try {
        const d = await chamar("/api/montar-sql", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ operacao: "select", banco, blocos }),
        });
        saidaMontar.textContent = d.sql; saidaMontar.hidden = false;
        btnCopiar.disabled = false; avisoMontar.hidden = true;
        definirStatus(statusMontar, "Comando gerado.", "status-ok");
        salvarHistorico("select", d.sql);
      } catch (e) {
        definirStatus(statusMontar, e.message || "falha ao gerar", "status-erro");
        saidaMontar.hidden = true; btnCopiar.disabled = true;
      }
      return;
    }

    if (!base()) { definirStatus(statusMontar, "Escolha a tabela.", "status-erro"); return; }
    const corpo = { operacao: tipo, tabela: base().nome, banco };

    if (tipo === "select") {
      corpo.campos = coletarCamposSelect();
      corpo.joins = coletarJoins();
      corpo.filtros = coletarFiltros();
    } else if (tipo === "update") {
      corpo.sets = setsUpdate.filter((s) => s.campo).map((s) => ({ campo: s.campo, valor: s.valor }));
      corpo.filtros = coletarFiltros();
    } else if (tipo === "delete") {
      corpo.filtros = coletarFiltros();
    } else if (tipo === "insert") {
      if (modoInsert === "select") {
        if (!fonteInsert) { definirStatus(statusMontar, "Escolha a tabela de origem.", "status-erro"); return; }
        corpo.pares = paresInsert.filter((p) => p.destino && p.origem).map((p) => ({ destino: p.destino, origem: p.origem }));
        corpo.fonte = { tabela: fonteInsert.nome, filtros: coletarFiltros(), joins: [] };
      } else {
        corpo.valores = valoresInsert.filter((v) => v.campo).map((v) => ({ campo: v.campo, valor: v.valor }));
      }
    }

    definirStatus(statusMontar, "Gerando...", "status-trabalhando");
    try {
      const d = await chamar("/api/montar-sql", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify(corpo),
      });
      saidaMontar.textContent = d.sql;
      saidaMontar.hidden = false;
      btnCopiar.disabled = false;
      if (d.aviso) { avisoMontar.textContent = d.aviso; avisoMontar.hidden = false; }
      else avisoMontar.hidden = true;
      definirStatus(statusMontar, "Comando gerado.", "status-ok");
      salvarHistorico(tipo, d.sql);
    } catch (e) {
      definirStatus(statusMontar, e.message || "falha ao gerar", "status-erro");
      saidaMontar.hidden = true; btnCopiar.disabled = true; avisoMontar.hidden = true;
    }
  });

  btnCopiar.addEventListener("click", () => copiar(saidaMontar.textContent, btnCopiar));

  btnLimpar.addEventListener("click", () => {
    tipo = "select";
    areaTipos.querySelectorAll(".tipo-opcao").forEach((x) => x.classList.toggle("ativo", x.dataset.tipo === "select"));
    banco = "oracle";
    areaBancos.querySelectorAll(".banco-opcao").forEach((x) => x.classList.toggle("ativo", x.dataset.banco === "oracle"));
    tabelas = []; filtros = []; setsUpdate = []; valoresInsert = []; paresInsert = [];
    fonteInsert = null; modoInsert = "valores"; pendenteCross = null;
    modoSelect = "simples"; blocosUnion = [];
    if (areaModos) areaModos.querySelectorAll(".modo-opcao").forEach((x) => x.classList.toggle("ativo", x.dataset.modo === "simples"));
    buscaTabela.value = "";
    listaTabelas.innerHTML = "";
    msgTabela("");
    atualizarRotulos();
    renderCampos(); renderDados(); atualizarDicaTabelas();
    limparSaida();
    buscaTabela.focus();
  });

  function limparSaida() {
    saidaMontar.hidden = true; saidaMontar.textContent = "";
    avisoMontar.hidden = true; btnCopiar.disabled = true;
    definirStatus(statusMontar, "");
  }

  // inicialização
  atualizarRotulos();
  renderCampos();
  renderDados();
})();

/* === Stepper do limite de tabelas (botões - e +) === */
(function initStepper() {
  document.querySelectorAll(".stepper-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      if (campoLimite.disabled) return;
      const passo = parseInt(btn.dataset.step, 10) || 0;
      const min = parseInt(campoLimite.min, 10) || 1;
      const max = parseInt(campoLimite.max, 10) || 100;
      let v = (parseInt(campoLimite.value, 10) || min) + passo;
      v = Math.max(min, Math.min(max, v));
      campoLimite.value = v;
      campoLimite.dispatchEvent(new Event("change", { bubbles: true }));
    });
  });
})();

/* === Histórico de comandos (localStorage) === */
const HIST_CHAVE = "comandosdml.historico";
let histFiltro = "todos";
let histDe = "";    // yyyy-mm-dd
let histAte = "";   // yyyy-mm-dd

function lerHistorico() {
  try { return JSON.parse(localStorage.getItem(HIST_CHAVE) || "[]"); }
  catch { return []; }
}

function salvarHistorico(tipo, sql) {
  if (!sql) return;
  const agora = new Date();
  const iso = agora.toISOString();
  const diaLocal = `${agora.getFullYear()}-${_p2(agora.getMonth() + 1)}-${_p2(agora.getDate())}`;
  const lista = lerHistorico();
  lista.unshift({
    tipo: (tipo || "select").toLowerCase(),
    sql: sql,
    quando: iso,
    dia: diaLocal,
  });
  // mantém no máximo 200 itens
  if (lista.length > 200) lista.length = 200;
  try { localStorage.setItem(HIST_CHAVE, JSON.stringify(lista)); } catch {}
}

function _p2(n) { return String(n).padStart(2, "0"); }
function formatarData(iso) {
  try { const d = new Date(iso); return `${_p2(d.getDate())}/${_p2(d.getMonth() + 1)}/${d.getFullYear()}`; }
  catch { return iso; }
}
function formatarHora(iso) {
  try { const d = new Date(iso); return `${_p2(d.getHours())}:${_p2(d.getMinutes())}`; }
  catch { return ""; }
}

function renderHistorico() {
  const area = el("historico-lista");
  if (!area) return;
  const todos = lerHistorico();
  // Extrai o dia local (yyyy-mm-dd). Itens novos têm campo 'dia' pré-computado;
  // itens antigos caem no fallback via Date. Retorna null se sem data.
  function diaDoItem(item) {
    if (item.dia) return item.dia;
    if (!item.quando) return null;
    try {
      const d = new Date(item.quando);
      if (isNaN(d.getTime())) return null;
      return `${d.getFullYear()}-${_p2(d.getMonth() + 1)}-${_p2(d.getDate())}`;
    } catch { return null; }
  }
  let lista = histFiltro === "todos" ? todos.slice() : todos.filter((x) => x.tipo === histFiltro);
  // Filtro por período: itens sem data (antigos) sempre aparecem quando há filtro,
  // para não sumirem misteriosamente.
  if (histDe) lista = lista.filter((x) => { const d = diaDoItem(x); return d === null || d >= histDe; });
  if (histAte) lista = lista.filter((x) => { const d = diaDoItem(x); return d === null || d <= histAte; });
  if (!lista.length) {
    const tipoTxt = histFiltro === "todos" ? "" : histFiltro.toUpperCase() + " ";
    const periodoTxt = (histDe || histAte) ? " no período selecionado" : "";
    area.innerHTML = `<p class="ajuda">Nenhum comando ${tipoTxt}encontrado${periodoTxt}. ${!histDe && !histAte ? 'Gere um comando na aba "Montar comando (sem IA)".' : "Tente outro período ou tipo."}</p>`;
    return;
  }
  // Agrupa por data (a lista já vem do mais recente para o mais antigo).
  const grupos = [];
  const porData = {};
  lista.forEach((item, i) => {
    const dia = formatarData(item.quando);
    if (!porData[dia]) { porData[dia] = []; grupos.push(dia); }
    porData[dia].push({ item, i });
  });

  area.innerHTML = grupos.map((dia) => {
    const itens = porData[dia].map(({ item, i }) => {
      const selo = `<span class="tab-tipojoin">${item.tipo.toUpperCase()}</span>`;
      return `<div class="hist-item">` +
        `<div class="hist-cabec">${selo}<span class="hist-data">${formatarHora(item.quando)}</span>` +
        `<button type="button" class="botao botao-secundario botao-mini hist-copiar" data-i="${i}">Copiar</button></div>` +
        `<pre class="saida-sql">${escaparHtml(item.sql)}</pre></div>`;
    }).join("");
    return `<div class="hist-grupo"><h3 class="hist-dia">${dia} <span class="hist-qtd">(${porData[dia].length})</span></h3>${itens}</div>`;
  }).join("");

  area.querySelectorAll(".hist-copiar").forEach((b) => {
    b.addEventListener("click", () => copiar(lista[parseInt(b.dataset.i, 10)].sql, b));
  });
}

(function initHistorico() {
  const filtros = el("hist-filtros");
  const btnLimpar = el("btn-hist-limpar");
  const inpDe = el("hist-de");
  const inpAte = el("hist-ate");
  const btnPeriodo = el("btn-hist-periodo-limpar");
  if (filtros) {
    filtros.querySelectorAll(".hist-filtro").forEach((b) => {
      b.addEventListener("click", () => {
        filtros.querySelectorAll(".hist-filtro").forEach((x) => x.classList.remove("ativo"));
        b.classList.add("ativo");
        histFiltro = b.dataset.f;
        renderHistorico();
      });
    });
  }
  // Converte dd/mm/aaaa -> yyyy-mm-dd para comparação, ou "" se inválido.
  function parseDdMm(v) {
    const m = (v || "").match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
    return m ? `${m[3]}-${m[2]}-${m[1]}` : "";
  }
  // Máscara automática: insere as barras enquanto digita.
  function mascaraData(inp) {
    inp.addEventListener("input", () => {
      let v = inp.value.replace(/\D/g, "").slice(0, 8);
      if (v.length > 4) v = v.slice(0, 2) + "/" + v.slice(2, 4) + "/" + v.slice(4);
      else if (v.length > 2) v = v.slice(0, 2) + "/" + v.slice(2);
      inp.value = v;
    });
  }
  if (inpDe) mascaraData(inpDe);
  if (inpAte) mascaraData(inpAte);
  const btnFiltrarData = el("btn-hist-filtrar-data");
  if (btnFiltrarData) {
    btnFiltrarData.addEventListener("click", () => {
      histDe = parseDdMm(inpDe ? inpDe.value : "");
      histAte = parseDdMm(inpAte ? inpAte.value : "");
      renderHistorico();
    });
  }
  if (btnPeriodo) {
    btnPeriodo.addEventListener("click", () => {
      histDe = ""; histAte = "";
      if (inpDe) inpDe.value = "";
      if (inpAte) inpAte.value = "";
      renderHistorico();
    });
  }
  if (btnLimpar) {
    btnLimpar.addEventListener("click", () => {
      if (!confirm("Apagar todo o histórico de comandos deste navegador?")) return;
      try { localStorage.removeItem(HIST_CHAVE); } catch {}
      renderHistorico();
    });
  }
})();

/* === Pesquisar por campo (literal ou técnico) === */
(function initPesquisaCampo() {
  const modos = el("campo-modos");
  const termo = el("campo-termo");
  const btn = el("btn-pesquisar-campo");
  const btnLimpar = el("btn-limpar-campo");
  const status = el("campo-status");
  const area = el("campo-resultado");
  if (!termo || !btn) return;
  let modo = "tecnico";

  modos.querySelectorAll(".banco-opcao").forEach((b) => {
    b.addEventListener("click", () => {
      modos.querySelectorAll(".banco-opcao").forEach((x) => x.classList.remove("ativo"));
      b.classList.add("ativo");
      modo = b.dataset.modo;
      termo.placeholder = modo === "literal" ? "Ex.: Id Contratado" : "Ex.: con_cdicontratado";
    });
  });

  async function pesquisar() {
    const q = termo.value.trim();
    if (q.length < 2) { definirStatus(status, "Digite ao menos 2 caracteres.", "status-erro"); return; }
    definirStatus(status, "Pesquisando...", "status-trabalhando");
    try {
      const d = await chamar(`/api/pesquisar-campo?q=${encodeURIComponent(q)}&por=${modo}`);
      const rs = d.resultados || [];
      if (!rs.length) {
        area.innerHTML = `<p class="ajuda">Nenhum campo encontrado para "${escaparHtml(q)}".</p>`;
        definirStatus(status, "0 resultado.", "status-trabalhando");
        return;
      }
      area.innerHTML =
        `<table class="tabela-campos"><thead><tr>` +
        `<th>Campo técnico</th><th>Objeto primitivo</th><th>Literal</th><th>Tabela</th>` +
        `</tr></thead><tbody>` +
        rs.map((r) => {
          const prim = r.primitivo ? (r.primitivo + (r.primitivo_descricao ? " — " + escaparHtml(r.primitivo_descricao) : "")) : "";
          const tab = (r.cod_tabela != null ? r.cod_tabela + " — " : "") + escaparHtml(r.tabela || "");
          return `<tr><td class="mono">${escaparHtml(r.campo)}</td><td>${prim}</td>` +
            `<td>${escaparHtml(r.literal || "")}</td><td>${tab}</td></tr>`;
        }).join("") + `</tbody></table>`;
      definirStatus(status, `${rs.length} resultado(s)${rs.length >= 100 ? " (mostrando os 100 primeiros)" : ""}.`, "status-ok");
    } catch (e) {
      definirStatus(status, e.message || "falha na pesquisa", "status-erro");
    }
  }
  function limpar() {
    termo.value = "";
    area.innerHTML = "";
    definirStatus(status, "");
    termo.focus();
  }

  btn.addEventListener("click", pesquisar);
  if (btnLimpar) btnLimpar.addEventListener("click", limpar);
  termo.addEventListener("keydown", (ev) => { if (ev.key === "Enter") { ev.preventDefault(); pesquisar(); } });
  // Limpa o resultado automaticamente ao apagar o texto.
  termo.addEventListener("input", () => {
    if (!termo.value.trim()) {
      area.innerHTML = "";
      definirStatus(status, "");
    }
  });
})();

/* === Navegação por abas === */
(function initAbas() {
  const cats = document.querySelectorAll(".aba.cat");
  const paineis = document.querySelectorAll(".painel-aba");

  // Ajuda por TELA (nível 3), reaproveitada no modal "?".
  const AJUDA = {
    gerar: `<p>Encontra as tabelas certas e monta um <strong>script para usar numa IA</strong> (Gemini, Copilot, ChatGPT, etc.) e criar o comando SQL.</p>
      <ul><li><strong>Passo 1:</strong> o dicionário já vem carregado; em <em>Usar outra versão</em> dá para enviar um <code>.TXT</code> novo.</li>
      <li><strong>Passo 2:</strong> descreva em português ou cite um campo (ex.: <code>PST_OplEfetivada</code>).</li>
      <li><strong>Tabelas exatas</strong> × <strong>Relacionadas</strong> (inclui ligadas por FK).</li>
      <li><strong>Solicitar pesquisa</strong> lista as tabelas; <strong>Gerar script</strong> monta o texto para colar na IA.</li></ul>`,
    montar: `<p>Monta o SQL direto na tela, passo a passo, <strong>sem IA e sem internet</strong>.</p>
      <ul><li><strong>Tipo:</strong> Consultar, Inserir, Alterar ou Apagar.</li>
      <li>Ao adicionar tabela com relação (ou view), a ferramenta liga o JOIN automaticamente.</li>
      <li>Escolha campos, monte filtros, selecione o banco e gere.</li></ul>
      <div class="aviso-ajuda">Antes de INSERT/UPDATE/DELETE: leia o comando, faça backup e confira o WHERE.</div>`,
    validar: `<p>Confere um comando contra o dicionário: tabelas e campos, chaves, objetos e avisos de risco.</p>
      <ul><li>Escolha o tipo, cole o comando e clique em <strong>Validar</strong>.</li>
      <li>Veja os pontos a revisar e o <strong>comando sugerido</strong> (dá para copiar só a correção).</li>
      <li>Reconhece <strong>views</strong> e aceita o JOIN view↔tabela. Não executa o comando.</li></ul>`,
    erro: `<p>Cole a mensagem de erro do banco e clique em <strong>Interpretar erro</strong>.</p>
      <ul><li>Identifica a tabela, índices e relações no dicionário e explica o erro — sem IA.</li>
      <li>Serve para chave única, FK, registro duplicado, campo obrigatório, etc.</li></ul>
      <div class="dica-ajuda">Em chave duplicada, sugere o objeto <strong>7027 — Recriação de Sequência</strong>.</div>`,
    campo: `<p>Encontra um campo pelo <strong>nome técnico</strong> (ex.: <code>CON_CdiContratado</code>) ou pelo <strong>literal</strong> (por aproximação).</p>
      <p>O resultado traz o campo técnico, o objeto primitivo, o literal e a tabela.</p>`,
    objeto: `<p>Descobre quais <strong>tabelas</strong> uma tela (objeto) do Apdata usa e as relações entre elas.</p>`,
    rotina: `<p>Chega às tabelas pela cadeia <strong>Módulo → Rotina → Objeto → Tabela</strong>. Dá para exportar em planilha (<code>.xlsx</code>).</p>`,
    historico: `<p>Guarda os comandos gerados em <strong>Montar comando</strong>, com data e hora. Filtra por tipo e período. Fica salvo só neste navegador.</p>`,
    validados: `<p>Guarda cada validação feita, com data, tipo e diagnóstico. Clique num item para ver o SQL e o diagnóstico completo.</p>`,
    ajuda: `<p>Guia completo da ferramenta, com cada tela e cada botão explicado.</p>`,
  };

  // Submenus por CATEGORIA (nível 1 -> nível 2).
  const CATEGORIAS = {
    criar: {
      nome: "Criar comando", icone: "\uE713",
      descricao: "Monte o comando SQL: gere um script para usar numa IA ou monte direto na tela, sem IA.",
      itens: [
        { aba: "gerar", icone: "\uE713", titulo: "Gerar script de comando", desc: "Acha as tabelas e monta o script para a IA." },
        { aba: "montar", icone: "\uE90F", titulo: "Montar comando (sem IA)", desc: "Monte o SQL passo a passo, direto na tela." },
      ],
    },
    conferir: {
      nome: "Conferir", icone: "\uE73E",
      descricao: "Valide um comando contra o dicionário ou interprete uma mensagem de erro do Apdata.",
      itens: [
        { aba: "validar", icone: "\uE73E", titulo: "Validar comando DML", desc: "Confere tabelas, campos, chaves e sugere correção." },
        { aba: "erro", icone: "\uE7BA", titulo: "Interpretar erro Apdata", desc: "Explica a mensagem de erro usando o dicionário." },
      ],
    },
    consultas: {
      nome: "Consultas e buscas", icone: "\uE721",
      descricao: "Pesquise a estrutura do Apdata por campo, por objeto (tela) ou pela cadeia módulo/rotina.",
      itens: [
        { aba: "campo", icone: "\uE721", titulo: "Pesquisar por campo", desc: "Por nome técnico ou pelo literal da tela." },
        { aba: "objeto", icone: "\uE8F1", titulo: "Pesquisar por objeto", desc: "Quais tabelas uma tela do Apdata usa." },
        { aba: "rotina", icone: "\uE721", titulo: "Pesquisar por módulo/rotina", desc: "Cadeia Módulo -> Rotina -> Objeto -> Tabela." },
      ],
    },
    historicos: {
      nome: "Históricos", icone: "\uE81C",
      descricao: "Veja os comandos gerados e as validações feitas, guardados neste navegador.",
      itens: [
        { aba: "historico", icone: "\uE81C", titulo: "Histórico de comandos", desc: "Comandos gerados em Montar comando." },
        { aba: "validados", icone: "\uE8FD", titulo: "Histórico de validações", desc: "Validações feitas em Validar comando." },
      ],
    },
    suporte: {
      nome: "Suporte", icone: "\uE897",
      descricao: "Guia completo da ferramenta, tela a tela.",
      itens: [
        { aba: "ajuda", icone: "\uE897", titulo: "Ajuda e guia", desc: "Como usar cada tela e cada botão." },
      ],
    },
  };

  // Em qual categoria cada aba está (para destacar a categoria ao abrir aba).
  const abaParaCategoria = {};
  Object.entries(CATEGORIAS).forEach(([catKey, cat]) => {
    cat.itens.forEach((it) => { abaParaCategoria[it.aba] = catKey; });
  });

  const painelCategoria = document.querySelector('.painel-aba[data-painel="menu-categoria"]');
  const grade = el("submenu-grade");
  const catNome = el("cat-nome");
  const catIcone = el("cat-icone");
  const catDescricao = el("cat-descricao");

  let categoriaAtual = "criar";

  function destacarCategoria(catKey) {
    cats.forEach((c) => c.classList.toggle("ativa", c.dataset.cat === catKey));
  }

  // Nível 2: mostra os cartões de submenu da categoria.
  function mostrarCategoria(catKey) {
    const cat = CATEGORIAS[catKey];
    if (!cat) return;
    categoriaAtual = catKey;
    destacarCategoria(catKey);
    catNome.textContent = cat.nome;
    catIcone.textContent = cat.icone;
    catDescricao.textContent = cat.descricao;
    grade.innerHTML = cat.itens.map((it) =>
      `<button type="button" class="submenu-card" data-ir="${it.aba}">
         <span class="submenu-icone ico-win">${it.icone}</span>
         <span class="submenu-txt"><strong>${escaparHtml(it.titulo)}</strong>
         <span class="submenu-desc">${escaparHtml(it.desc)}</span></span>
       </button>`).join("");
    grade.querySelectorAll(".submenu-card").forEach((b) => {
      b.addEventListener("click", () => ativarAba(b.dataset.ir));
    });
    paineis.forEach((p) => { p.hidden = p.dataset.painel !== "menu-categoria"; });
    window.scrollTo({ top: 0, behavior: "auto" });
  }

  // Nível 3: abre a tela de ação (os painéis existentes), com botão "voltar"
  // à categoria e botão de ajuda "?" específico da tela.
  function ativarAba(alvo) {
    const painel = document.querySelector('.painel-aba[data-painel="' + alvo + '"]');
    if (!painel) return;
    const catKey = abaParaCategoria[alvo] || categoriaAtual;
    destacarCategoria(catKey);
    paineis.forEach((p) => { p.hidden = p.dataset.painel !== alvo; });
    injetarBarraTela(painel, alvo, catKey);
    if (alvo === "historico") renderHistorico();
    if (alvo === "validados" && window.renderValidados) window.renderValidados();
    window.scrollTo({ top: 0, behavior: "auto" });
  }

  // Insere, no topo do painel, uma barra com "voltar" e "ajuda" (uma vez só).
  function injetarBarraTela(painel, alvo, catKey) {
    let barra = painel.querySelector(".tela-barra");
    if (!barra) {
      barra = document.createElement("div");
      barra.className = "tela-barra";
      const voltar = document.createElement("button");
      voltar.type = "button";
      voltar.className = "botao botao-secundario botao-mini tela-voltar";
      voltar.innerHTML = "&#8592; Voltar";
      const ajuda = document.createElement("button");
      ajuda.type = "button";
      ajuda.className = "botao botao-secundario botao-mini tela-ajuda";
      ajuda.innerHTML = "&#10067; Ajuda desta tela";
      barra.appendChild(voltar);
      barra.appendChild(ajuda);
      painel.insertBefore(barra, painel.firstChild);
      barra._voltar = voltar; barra._ajuda = ajuda;
    }
    barra._voltar.onclick = () => mostrarCategoria(catKey);
    barra._ajuda.onclick = () => abrirAjuda(alvo);
  }

  // Modal de ajuda da tela.
  const overlay = el("ajuda-overlay");
  const ajTitulo = el("ajuda-titulo");
  const ajConteudo = el("ajuda-conteudo");
  function abrirAjuda(alvo) {
    const cat = CATEGORIAS[abaParaCategoria[alvo]];
    const item = cat ? cat.itens.find((i) => i.aba === alvo) : null;
    ajTitulo.textContent = "Ajuda — " + (item ? item.titulo : alvo);
    ajConteudo.innerHTML = AJUDA[alvo] || "<p>Sem ajuda para esta tela.</p>";
    overlay.hidden = false;
  }
  function fecharAjuda() { overlay.hidden = true; }
  el("ajuda-fechar").addEventListener("click", fecharAjuda);
  overlay.addEventListener("click", (ev) => { if (ev.target === overlay) fecharAjuda(); });
  document.addEventListener("keydown", (ev) => { if (ev.key === "Escape" && !overlay.hidden) fecharAjuda(); });

  // Clique nas categorias do topo.
  cats.forEach((c) => {
    const txt = (c.querySelector(".aba-texto")?.textContent || "").trim();
    if (txt) { c.title = txt; c.setAttribute("aria-label", txt); }
    c.addEventListener("click", () => mostrarCategoria(c.dataset.cat));
  });

  // Deep-link por hash: #<aba> abre a tela; #cat-<categoria> abre a categoria.
  function aplicarHash() {
    const h = (location.hash || "").replace(/^#/, "");
    if (!h) { mostrarCategoria("criar"); return; }
    if (h.startsWith("cat-")) { mostrarCategoria(h.slice(4)); return; }
    if (abaParaCategoria[h]) { ativarAba(h); return; }
    mostrarCategoria("criar");
  }
  window.addEventListener("hashchange", aplicarHash);
  aplicarHash();
})();

/* === Validar comando DML === */
(function initValidar() {
  const tipos = el("validar-tipos");
  const sql = el("validar-sql");
  const btn = el("btn-validar");
  const btnLimpar = el("btn-validar-limpar");
  const btnCopiar = el("btn-validar-copiar");
  const status = el("validar-status");
  const area = el("validar-resultado");
  if (!sql || !btn) return;

  let tipo = "SELECT";
  let ultimoTexto = "";
  const HISTV = "comandosdml.validacoes";

  autoCrescer(sql);  // textarea cresce conforme o comando colado

  tipos.querySelectorAll(".banco-opcao").forEach((b) => {
    b.addEventListener("click", () => {
      tipos.querySelectorAll(".banco-opcao").forEach((x) => x.classList.remove("ativo"));
      b.classList.add("ativo");
      tipo = b.dataset.tipo;
    });
  });

  function lerHistV() {
    try { return JSON.parse(localStorage.getItem(HISTV) || "[]"); }
    catch { return []; }
  }
  function salvarHistV(item) {
    const lista = lerHistV();
    lista.unshift(item);
    if (lista.length > 100) lista.length = 100;
    try { localStorage.setItem(HISTV, JSON.stringify(lista)); } catch {}
  }

  function badge(texto, cor) {
    return `<span class="val-badge val-${cor}">${escaparHtml(texto)}</span>`;
  }

  function montarTextoDiag(d) {
    // Texto puro para o botão Copiar e para o histórico.
    const linhas = [];
    linhas.push(`Tipo: ${d.tipo}` + (d.tipo_detectado && d.tipo_detectado !== d.tipo ? ` (detectado: ${d.tipo_detectado})` : ""));
    linhas.push(d.ok ? "Situação: sem problemas encontrados" : "Situação: há pontos a revisar");
    if ((d.avisos || []).length) {
      linhas.push("");
      linhas.push("Avisos:");
      d.avisos.forEach((a) => linhas.push("  ! " + a));
    }
    if (d.leitura) { linhas.push(""); linhas.push(d.leitura); }
    if (d.sugerido) { linhas.push(""); linhas.push("Comando sugerido:"); linhas.push(d.sugerido); }
    return linhas.join("\n");
  }

  function render(d) {
    const partes = [];
    partes.push(`<div class="val-cab">`);
    partes.push(d.ok ? badge("Sem problemas encontrados", "ok")
                     : badge("Revisar pontos abaixo", "alerta"));
    partes.push(` ${badge("Tipo: " + d.tipo, "neutro")}`);
    if (d.tipo_detectado && d.tipo_detectado !== d.tipo) {
      partes.push(` ${badge("Detectado: " + d.tipo_detectado, "neutro")}`);
    }
    partes.push(`</div>`);

    if ((d.avisos || []).length) {
      partes.push(`<div class="val-avisos">`);
      d.avisos.forEach((a) => partes.push(`<div class="val-aviso">⚠ ${escaparHtml(a)}</div>`));
      partes.push(`</div>`);
    }

    // Tabelas
    if ((d.tabelas || []).length) {
      partes.push(`<h3 class="val-h3">Tabelas</h3><ul class="val-lista">`);
      d.tabelas.forEach((t) => {
        if (t.existe) {
          let o = "";
          if (t.objeto) o = ` <span class="leve">(objeto ${t.objeto.id}${t.objeto.descricao ? " — " + escaparHtml(t.objeto.descricao) : ""})</span>`;
          let selo = "";
          if (t.eh_view) {
            const vb = (t.view && t.view.banco) ? " " + escaparHtml(t.view.banco) : "";
            selo = ` <span class="val-badge val-view">VIEW${vb}</span>`;
          }
          partes.push(`<li>✔ <span class="mono">${escaparHtml(t.nome)}</span>${selo}${o}</li>`);
        } else {
          let sug = (t.sugestoes || []).length ? ` <span class="leve">→ você quis dizer: ${t.sugestoes.map(escaparHtml).join(", ")}?</span>` : "";
          partes.push(`<li>✗ <span class="mono">${escaparHtml(t.nome)}</span> não encontrada${sug}</li>`);
        }
      });
      partes.push(`</ul>`);
    }

    // Campos com problema
    const ruins = (d.campos || []).filter((c) => c.status !== "ok");
    if (ruins.length) {
      partes.push(`<h3 class="val-h3">Campos a revisar</h3><ul class="val-lista">`);
      ruins.forEach((c) => {
        if (c.status === "inexistente") {
          let sug = (c.sugestoes || []).length ? ` <span class="leve">→ talvez: ${c.sugestoes.map(escaparHtml).join(", ")}</span>` : "";
          partes.push(`<li>✗ <span class="mono">${escaparHtml(c.campo)}</span> não existe em ${escaparHtml(c.tabela)}${sug}</li>`);
        } else if (c.status === "view_ausente") {
          partes.push(`<li>${badge("VIEW", "view")} <span class="mono">${escaparHtml(c.campo)}</span> — ${escaparHtml(c.detalhe || "")}</li>`);
        } else if (c.status === "tabela_ausente") {
          partes.push(`<li>⚠ <span class="mono">${escaparHtml(c.campo)}</span> — ${escaparHtml(c.detalhe || "")}</li>`);
        } else {
          partes.push(`<li>? <span class="mono">${escaparHtml(c.campo)}</span> — ${escaparHtml(c.detalhe || "prefixo não reconhecido")}</li>`);
        }
      });
      partes.push(`</ul>`);
    }

    // Comando sugerido — vem logo após os problemas, em destaque (é o que o
    // usuário mais quer). Fica antes da leitura detalhada.
    if (d.sugerido) {
      partes.push(
        `<div class="val-sug-cab">` +
          `<h3 class="val-h3" style="border:0;margin:0.9rem 0 0.3rem">Comando sugerido (correção segura)</h3>` +
          `<button type="button" class="botao botao-secundario botao-mini" id="btn-val-copiar-sugerido">Copiar comando corrigido</button>` +
        `</div>` +
        `<pre class="val-sugerido">${escaparHtml(d.sugerido)}</pre>`
      );
    }

    // Leitura (interpretação determinística) — recolhida por padrão, para não
    // alongar a tela. Abre só se o usuário quiser os detalhes.
    if (d.leitura) {
      partes.push(
        `<details class="val-detalhe"><summary>Ver leitura do dicionário (tabelas, relações)</summary>` +
        `<pre class="val-leitura">${escaparHtml(d.leitura)}</pre></details>`
      );
    }

    if (d.nota) {
      partes.push(`<p class="ajuda val-nota">${escaparHtml(d.nota)}</p>`);
    }

    area.innerHTML = partes.join("");

    // Liga o botão de copiar o comando corrigido, se houver sugestão.
    const btnSug = el("btn-val-copiar-sugerido");
    if (btnSug && d.sugerido) {
      btnSug.addEventListener("click", () => copiar(d.sugerido, btnSug));
    }
  }

  // Histórico de validações, exibido na ABA PRÓPRIA (#validados-lista).
  // Exposto no window para o initAbas chamar ao abrir a aba.
  window.renderValidados = function renderValidados() {
    const area2 = el("validados-lista");
    if (!area2) return;
    const lista = lerHistV();
    if (!lista.length) {
      area2.innerHTML = `<p class="ajuda">Nenhuma validação ainda. Use a aba "Validar comando DML".</p>`;
      return;
    }
    area2.innerHTML = lista.map((it) => {
      const quando = new Date(it.quando).toLocaleString("pt-BR");
      return `<details class="val-hist-item"><summary>${badge(it.tipo, "neutro")} `
        + `${badge(it.ok ? "ok" : "revisar", it.ok ? "ok" : "alerta")} `
        + `<span class="leve">${escaparHtml(quando)}</span></summary>`
        + `<pre class="val-leitura">${escaparHtml(it.sql)}</pre>`
        + `<pre class="val-leitura">${escaparHtml(it.diag)}</pre></details>`;
    }).join("");
  };

  const btnHistLimpar = el("btn-val-hist-limpar");
  if (btnHistLimpar) btnHistLimpar.addEventListener("click", () => {
    if (!confirm("Apagar o histórico de validações deste navegador?")) return;
    try { localStorage.removeItem(HISTV); } catch {}
    window.renderValidados();
  });

  async function validar() {
    const texto = sql.value.trim();
    if (texto.length < 6) { definirStatus(status, "Cole um comando com ao menos alguns caracteres.", "status-erro"); return; }
    definirStatus(status, "Validando...", "status-trabalhando");
    btn.disabled = true;
    try {
      const d = await chamar("/api/validar-dml", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sql: texto, tipo }),
      });
      ultimoTexto = montarTextoDiag(d);
      // Grava no histórico (exibido na aba própria "Histórico de validações").
      salvarHistV({ tipo: d.tipo, ok: !!d.ok, quando: new Date().toISOString(), sql: texto, diag: ultimoTexto });
      area.hidden = false;
      render(d);
      btnCopiar.disabled = false;
      definirStatus(status, d.ok ? "Validação concluída: sem problemas." : "Validação concluída: há pontos a revisar.", d.ok ? "status-ok" : "status-trabalhando");
      area.scrollIntoView({ behavior: "smooth", block: "start" });
    } catch (e) {
      definirStatus(status, e.message || "falha na validação", "status-erro");
    } finally {
      btn.disabled = false;
    }
  }

  function limpar() {
    sql.value = "";
    sql.style.height = "";       // volta à altura inicial
    area.innerHTML = "";
    area.hidden = true;
    btnCopiar.disabled = true;
    definirStatus(status, "");
    sql.focus();
  }

  btn.addEventListener("click", validar);
  btnLimpar.addEventListener("click", limpar);
  btnCopiar.addEventListener("click", () => { if (ultimoTexto) copiar(ultimoTexto, btnCopiar); });
})();

/* Selo de versão: lido de web/versao.txt, gerado automaticamente a cada
   compilação do pacote (gerar-pacote-app.ps1 grava a data do build). Em
   ambiente de desenvolvimento o arquivo pode não existir — aí fica o texto
   padrão que já está no HTML. */
(async function carregarVersao() {
  const selo = el("selo-versao");
  if (!selo) return;
  try {
    const resp = await fetch("versao.txt", { cache: "no-store" });
    if (!resp.ok) return;
    const txt = (await resp.text()).trim();
    if (txt) selo.textContent = txt;
  } catch { /* mantém o texto do HTML */ }
})();

saudar();
verificarServidor();
aplicarEstado();

/* Reconecta na hora quando a janela volta ao foco ou a aba fica visível de
   novo. Navegadores reduzem os timers em segundo plano, então ao voltar o
   usuário dispara um heartbeat imediato — o servidor recebe sinal e a tela
   confirma que está online sem esperar o próximo ciclo. */
function pingarAgora() {
  if (timerVerificacao) clearTimeout(timerVerificacao);
  verificarServidor();
}
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "visible") pingarAgora();
});
window.addEventListener("focus", pingarAgora);
window.addEventListener("online", pingarAgora);
